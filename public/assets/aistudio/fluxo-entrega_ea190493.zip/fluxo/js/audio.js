'use strict';
/* ============ audio.js — música de fundo e sons (Web Audio) ============ */
const TRACK_LABELS = { none: '—', rain: 'Chuva', ocean: 'Oceano', pad: 'Ambiente', lofi: 'Lo-fi', custom: 'Sua música' };

const Sound = {
  ctx: null,
  master: null,
  bgm: null,
  nodes: [],
  timers: [],
  noiseBuf: null,
  playing: false,
  padInterval: null,

  init() {
    this.bgm = $('#bgm');
    this.bgm.volume = Store.state.music.volume;
  },

  ensureCtx() {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    if (!this.ctx) {
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = Store.state.music.volume;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
    return this.ctx;
  },

  setVolume(v) {
    Store.state.music.volume = v;
    if (this.ctx && this.master) {
      this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.05);
    }
    if (this.bgm) this.bgm.volume = v;
    Store.save();
  },

  setCustomSource(url) { if (this.bgm) this.bgm.src = url; },

  noise() {
    if (this.noiseBuf) return this.noiseBuf;
    const ctx = this.ctx;
    const buf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    this.noiseBuf = buf;
    return buf;
  },

  play(track) {
    track = track || Store.state.music.track;
    Store.state.music.track = track;
    this.stop(true);
    if (!track || track === 'none') { Store.save(); this.updateUI(); return; }

    if (track === 'custom') {
      if (!this.bgm.src) { toast('Envie um arquivo de música no painel', 'music'); this.updateUI(); return; }
      this.bgm.play().catch(() => {});
      this.playing = true;
      Store.save(); this.updateUI();
      return;
    }

    const ctx = this.ensureCtx();
    if (!ctx) { toast('Áudio não suportado neste navegador', 'close'); return; }
    try {
      if (track === 'rain') this.buildRain();
      else if (track === 'ocean') this.buildOcean();
      else if (track === 'pad') this.buildPad();
      else if (track === 'lofi') this.buildLofi();
      this.playing = true;
    } catch (e) { /* falha silenciosa */ }
    Store.save();
    this.updateUI();
  },

  stop(silent) {
    this.timers.forEach(clearTimeout); this.timers = [];
    if (this.padInterval) { clearInterval(this.padInterval); this.padInterval = null; }
    this.nodes.forEach(n => { try { if (n.stop) n.stop(); } catch (e) {} try { n.disconnect(); } catch (e) {} });
    this.nodes = [];
    if (this.bgm) this.bgm.pause();
    if (!silent) {
      this.playing = false;
      this.updateUI();
    }
  },

  toggle() {
    if (this.playing) this.stop();
    else if (Store.state.music.track === 'none') this.play('rain');
    else this.play();
  },

  /* ---------- trilhas geradas ---------- */
  buildRain() {
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.noise(); src.loop = true;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass'; bp.frequency.value = 1500; bp.Q.value = 0.45;
    const g = ctx.createGain(); g.gain.value = 0.55;
    src.connect(bp); bp.connect(g); g.connect(this.master);

    // variação suave na frequência da chuva
    const lfo = ctx.createOscillator(); lfo.frequency.value = 0.13;
    const lg = ctx.createGain(); lg.gain.value = 260;
    lfo.connect(lg); lg.connect(bp.frequency);

    // rumble grave
    const src2 = ctx.createBufferSource();
    src2.buffer = this.noise(); src2.loop = true;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 280;
    const g2 = ctx.createGain(); g2.gain.value = 0.30;
    src2.connect(lp); lp.connect(g2); g2.connect(this.master);

    src.start(); src2.start(); lfo.start();
    this.nodes.push(src, src2, lfo);
  },

  buildOcean() {
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.noise(); src.loop = true;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 480; lp.Q.value = 0.7;
    const g = ctx.createGain(); g.gain.value = 0.0;
    src.connect(lp); lp.connect(g); g.connect(this.master);

    // ondas: LFO lento sobre o ganho (com offset via ConstantSource quando disponível)
    if (ctx.createConstantSource) {
      const off = ctx.createConstantSource(); off.offset.value = 0.42;
      const lfo = ctx.createOscillator(); lfo.frequency.value = 0.055;
      const lg = ctx.createGain(); lg.gain.value = 0.38;
      off.connect(g.gain); lfo.connect(lg); lg.connect(g.gain);
      off.start(); lfo.start();
      this.nodes.push(off, lfo);
    } else {
      g.gain.value = 0.42;
    }

    // camada de espuma
    const src2 = ctx.createBufferSource();
    src2.buffer = this.noise(); src2.loop = true;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass'; bp.frequency.value = 1400; bp.Q.value = 0.5;
    const g2 = ctx.createGain(); g2.gain.value = 0.05;
    src2.connect(bp); bp.connect(g2); g2.connect(this.master);

    src.start(); src2.start();
    this.nodes.push(src, src2);
  },

  playChord(chord, when, dur, tone, gainVal, lp) {
    const ctx = this.ctx;
    chord.forEach((f, idx) => {
      const o = ctx.createOscillator();
      o.type = tone; o.frequency.value = f;
      o.detune.value = (idx - 1) * 5;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, when);
      g.gain.linearRampToValueAtTime(gainVal, when + dur * 0.30);
      g.gain.setValueAtTime(gainVal, when + dur * 0.55);
      g.gain.linearRampToValueAtTime(0.0001, when + dur * 0.98);
      o.connect(g); g.connect(lp);
      o.start(when); o.stop(when + dur);
      this.timers.push(setTimeout(() => { try { o.disconnect(); g.disconnect(); } catch (e) {} }, dur * 1000 + 200));
    });
  },

  buildPad(chords, intervalMs, tone, cutoff) {
    const ctx = this.ctx;
    chords = chords || [
      [220.00, 261.63, 329.63],
      [174.61, 220.00, 261.63],
      [130.81, 164.81, 196.00],
      [196.00, 246.94, 293.66]
    ];
    intervalMs = intervalMs || 9000;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = cutoff || 1500;
    lp.connect(this.master);
    let i = 0;
    const dur = intervalMs / 1000;
    const step = () => {
      if (!this.playing) return;
      const t = ctx.currentTime + 0.05;
      this.playChord(chords[i % chords.length], t, dur, tone || 'triangle', 0.085, lp);
      i++;
    };
    step();
    this.padInterval = setInterval(step, intervalMs);
    this.nodes.push(lp);
  },

  buildLofi() {
    const ctx = this.ctx;
    const chords = [
      [174.61, 220.00, 261.63],  // F
      [196.00, 246.94, 293.66],  // G
      [130.81, 164.81, 196.00],  // C
      [164.81, 220.00, 246.94]   // E menor
    ];
    this.buildPad(chords, 6800, 'triangle', 950);

    // chiado de vinil
    const tick = () => {
      if (!this.playing) return;
      try {
        const src = ctx.createBufferSource();
        src.buffer = this.noise();
        const bp = ctx.createBiquadFilter();
        bp.type = 'highpass'; bp.frequency.value = 3200;
        const g = ctx.createGain();
        g.gain.value = 0.015 + Math.random() * 0.05;
        src.connect(bp); bp.connect(g); g.connect(this.master);
        src.start(ctx.currentTime, Math.random() * 1.5, 0.03);
        this.timers.push(setTimeout(() => { try { src.disconnect(); } catch (e) {} }, 300));
      } catch (e) {}
      this.timers.push(setTimeout(tick, 60 + Math.random() * 280));
    };
    tick();
  },

  /* ---------- efeitos pontuais ---------- */
  chime() {
    const ctx = this.ensureCtx();
    if (!ctx) return;
    const vol = clamp(Store.state.music.volume * 1.3, 0.15, 0.9);
    [660, 880].forEach((f, i) => {
      const t = ctx.currentTime + i * 0.18;
      const o = ctx.createOscillator();
      o.type = 'sine'; o.frequency.value = f;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(vol, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
      o.connect(g); g.connect(ctx.destination);
      o.start(t); o.stop(t + 1);
      setTimeout(() => { try { o.disconnect(); g.disconnect(); } catch (e) {} }, 1300);
    });
  },

  pop() {
    const ctx = this.ensureCtx();
    if (!ctx) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(520, t);
    o.frequency.exponentialRampToValueAtTime(760, t + 0.09);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.22, t + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
    o.connect(g); g.connect(ctx.destination);
    o.start(t); o.stop(t + 0.2);
    setTimeout(() => { try { o.disconnect(); g.disconnect(); } catch (e) {} }, 400);
  },

  updateUI() {
    if (typeof HomePage !== 'undefined') HomePage.updateMusicChip();
  }
};
