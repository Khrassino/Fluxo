'use strict';
/* ============ panel.js — painel de personalização ============ */

/* ---- construtores de controles ---- */
function pSection(icon, title) {
  const sec = el('div', 'panel-section');
  sec.append(el('h3', null, svgIcon(icon) + '<span>' + title + '</span>'));
  return sec;
}
function pSub(title) {
  return el('h4', 'panel-sub', title);
}
function pCtl(labelHtml) {
  const c = el('div', 'ctl');
  if (labelHtml) c.append(el('div', 'ctl-label', labelHtml));
  return c;
}
function chipGroup(options, active, onPick) {
  const grid = el('div', 'chip-grid');
  options.forEach(o => {
    const b = el('button', 'chip' + (o.id === active ? ' active' : ''));
    if (o.icon) b.innerHTML = svgIcon(o.icon) + '<span>' + o.label + '</span>';
    else b.textContent = o.label;
    if (o.cls) b.classList.add(o.cls);
    if (o.style) Object.assign(b.style, o.style);
    b.addEventListener('click', () => onPick(o.id));
    grid.append(b);
  });
  return grid;
}
function sliderRow(label, min, max, value, fmt, onInput, step) {
  const c = el('div', 'ctl');
  const lab = el('div', 'ctl-label', '<span>' + label + '</span><b></b>');
  const b = lab.querySelector('b');
  b.textContent = fmt(value);
  const input = el('input');
  input.type = 'range'; input.min = min; input.max = max; input.step = step || 1; input.value = value;
  input.addEventListener('input', () => { b.textContent = fmt(+input.value); onInput(+input.value); });
  c.append(lab, input);
  return c;
}
function switchRow(label, checked, onChange) {
  const row = el('div', 'switch-row', '<span>' + label + '</span>');
  const sw = el('button', 'switch' + (checked ? ' on' : ''));
  sw.setAttribute('role', 'switch');
  sw.setAttribute('aria-checked', checked ? 'true' : 'false');
  sw.addEventListener('click', () => {
    const on = !sw.classList.contains('on');
    sw.classList.toggle('on', on);
    sw.setAttribute('aria-checked', on ? 'true' : 'false');
    onChange(on);
  });
  row.append(sw);
  return row;
}
function numRow(label, value, min, max, onChange) {
  const row = el('div', 'num-row', '<label>' + label + '</label>');
  const inp = el('input');
  inp.type = 'number'; inp.min = min; inp.max = max; inp.value = value;
  inp.addEventListener('change', () => {
    const v = clamp(Math.round(+inp.value || min), min, max);
    inp.value = v;
    onChange(v);
  });
  row.append(inp);
  return row;
}
function uploadBtn(label, accept, onFile) {
  const lab = el('label', 'upload-btn', svgIcon('upload') + '<span>' + label + '</span>');
  const inp = el('input');
  inp.type = 'file'; inp.accept = accept;
  inp.addEventListener('change', () => {
    const f = inp.files[0];
    inp.value = '';
    if (f) onFile(f);
  });
  lab.append(inp);
  return lab;
}
function colorField(label, value, onChange) {
  const row = el('div', 'color-field');
  row.append(el('span', 'color-field-label', label));
  const picker = el('input');
  picker.type = 'color';
  picker.value = value;
  picker.title = label;
  picker.addEventListener('input', () => onChange(picker.value));
  row.append(picker);
  return row;
}

const PANEL_DRAWERS = [
  { id: 'appearance', label: 'Aparência',        icon: 'image' },
  { id: 'themes',     label: 'Temas e cores',    icon: 'palette' },
  { id: 'effects',    label: 'Efeitos',          icon: 'motion' },
  { id: 'timer',      label: 'Cronômetro',       icon: 'timer' },
  { id: 'home',       label: 'Início',           icon: 'home' },
  { id: 'tracker',    label: 'Estatísticas',     icon: 'chart' },
  { id: 'tasks',      label: 'Tarefas',          icon: 'tasks' },
  { id: 'shortcuts',  label: 'Atalhos',          icon: 'grid' },
  { id: 'general',    label: 'Geral',            icon: 'sliders' }
];

const Panel = {
  openId: 'appearance',

  init() {
    $('#panel-close').innerHTML = svgIcon('close');
    $('#panel-close').addEventListener('click', () => this.close());
    $('#panel-backdrop').addEventListener('click', () => this.close());
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') this.close();
    });
    this.render();
  },

  open() {
    document.body.classList.add('panel-open');
    if (typeof Idle !== 'undefined') Idle.wake();
    this.render();
  },
  close() {
    document.body.classList.remove('panel-open');
    if (typeof Idle !== 'undefined') Idle.wake();
  },
  toggle() {
    if (document.body.classList.contains('panel-open')) this.close();
    else this.open();
  },

  buildDrawer(id) {
    const builders = {
      appearance: () => this.appearanceSection(),
      themes:     () => this.themesSection(),
      effects:    () => this.effectsSection(),
      timer:      () => this.timerSection(),
      home:       () => this.homeSection(),
      tracker:    () => this.trackerSection(),
      tasks:      () => this.tasksSection(),
      shortcuts:  () => this.shortcutsSection(),
      general:    () => this.generalSection()
    };
    return (builders[id] || builders.appearance)();
  },

  toggleDrawer(id) {
    this.openId = this.openId === id ? null : id;
    this.render();
    const head = $('#panel-body .panel-drawer.open .drawer-head');
    if (head) head.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  },

  render() {
    const body = $('#panel-body');
    if (!body) return;
    const scroll = body.scrollTop;
    body.innerHTML = '';
    PANEL_DRAWERS.forEach(d => {
      const open = d.id === this.openId;
      const drawer = el('section', 'panel-drawer' + (open ? ' open' : ''));
      const head = el('button', 'drawer-head');
      head.type = 'button';
      head.setAttribute('aria-expanded', open ? 'true' : 'false');
      head.innerHTML =
        '<span class="drawer-icon">' + svgIcon(d.icon) + '</span>' +
        '<span class="drawer-title">' + d.label + '</span>' +
        '<span class="drawer-chev">' + svgIcon('chevD') + '</span>';
      head.addEventListener('click', () => this.toggleDrawer(d.id));
      const wrap = el('div', 'drawer-body');
      const inner = el('div', 'drawer-inner');
      if (open) inner.append(this.buildDrawer(d.id));
      wrap.append(inner);
      drawer.append(head, wrap);
      body.append(drawer);
    });
    body.scrollTop = scroll;
  },

  /* ================= temas e cores ================= */
  themesSection() {
    const a = Store.state.appearance;
    const sec = pSection('palette', 'Temas e cores');

    const themeCtl = pCtl('<span>Tema</span>');
    const tGrid = el('div', 'theme-grid');
    THEMES.forEach(t => {
      const active = t.id === a.theme;
      const b = el('button', 'theme-card' + (active ? ' active' : ''));
      b.dataset.theme = t.id;
      b.title = t.label;
      const customTheme = t.id === 'custom';
      const bg = customTheme ? (a.custom.bg || t.bg) : t.bg;
      const accent = customTheme ? (a.custom.accent || t.accent) : t.accent;
      const accent2 = customTheme ? (a.custom.accent2 || t.accent2) : t.accent2;
      const ink = customTheme ? (a.custom.text || t.ink) : t.ink;
      b.style.setProperty('--tc-bg', bg);
      b.style.setProperty('--tc-accent', accent);
      b.style.setProperty('--tc-accent2', accent2);
      b.style.setProperty('--tc-ink', ink);
      b.innerHTML =
        '<span class="theme-glyph">' + svgIcon(t.icon || 'palette') + '</span>' +
        '<span class="theme-dots"><i></i><i></i></span>' +
        '<span class="theme-name">' + t.label + '</span>';
      b.addEventListener('click', () => {
        Store.state.appearance.theme = t.id;
        Themes.apply();
        Store.save();
        this.render();
      });
      tGrid.append(b);
    });
    themeCtl.append(tGrid);
    sec.append(themeCtl);

    if (a.theme === 'custom') {
      const c = a.custom || {};
      const ctl = pCtl('<span>Cores do seu tema</span>');
      const grid = el('div', 'custom-colors');
      const set = (key, val) => {
        Store.state.appearance.custom[key] = val;
        Themes.apply();
        Store.save();
      };
      grid.append(colorField('Fundo', c.bg || '#0a0e1e', v => set('bg', v)));
      grid.append(colorField('Destaque', c.accent || '#8fa2ff', v => set('accent', v)));
      grid.append(colorField('Destaque 2', c.accent2 || '#5fe3c4', v => set('accent2', v)));
      grid.append(colorField('Texto', c.text || '#edf1ff', v => set('text', v)));
      ctl.append(grid);
      ctl.append(sliderRow('Vidro (opacidade)', 0, 100, c.glass == null ? 55 : c.glass, v => v + '%', v => {
        Store.state.appearance.custom.glass = v;
        Themes.apply();
        Store.save();
      }));
      const reset = el('button', 'chip', 'Voltar ao padrão');
      reset.style.marginTop = '6px';
      reset.addEventListener('click', () => {
        Store.state.appearance.custom = Store.defaults().appearance.custom;
        Themes.apply();
        Store.save();
        this.render();
      });
      ctl.append(reset);
      sec.append(ctl);
    }

    return sec;
  },

  /* ================= aparência ================= */
  appearanceSection() {
    const a = Store.state.appearance;
    const sec = pSection('image', 'Aparência');

    const wpCtl = pCtl('<span>Papel de parede</span>');
    const wGrid = el('div', 'wall-grid');
    WALLPAPERS.forEach(w => {
      const b = el('button', 'wall-card' + (w.id === a.wallpaper ? ' active' : ''));
      b.style.background = w.id === 'nenhum' ? 'var(--bg)' : w.bg;
      b.title = w.label;
      b.innerHTML = '<span class="wall-name">' + w.label + '</span>';
      b.addEventListener('click', () => {
        Store.state.appearance.wallpaper = w.id;
        Themes.apply();
        Store.save();
        this.render();
      });
      wGrid.append(b);
    });
    const custom = el('button', 'wall-card' + (a.wallpaper === 'custom' ? ' active' : ''));
    custom.style.background = Themes.customWallpaperUrl
      ? 'url("' + Themes.customWallpaperUrl + '") center/cover'
      : 'var(--surface-2)';
    custom.title = 'Sua imagem';
    custom.innerHTML = '<span class="wall-name">Sua imagem</span>';
    custom.addEventListener('click', () => {
      if (!Themes.customWallpaperUrl) { toast('Envie uma imagem primeiro', 'image'); return; }
      Store.state.appearance.wallpaper = 'custom';
      Themes.apply();
      Store.save();
      this.render();
    });
    wGrid.append(custom);
    wpCtl.append(wGrid);

    const uploads = el('div', 'chip-grid');
    uploads.style.marginTop = '12px';
    uploads.append(uploadBtn('Enviar imagem', 'image/*', async (file) => {
      if (!file.type.startsWith('image/')) { toast('Escolha um arquivo de imagem', 'close'); return; }
      if (file.size > 8 * 1024 * 1024) { toast('Imagem muito grande (máx. 8 MB)', 'close'); return; }
      try {
        const url = await readFileAsDataURL(file);
        await Files.put('customWallpaper', url);
        Themes.customWallpaperUrl = url;
        Store.state.appearance.wallpaper = 'custom';
        Store.save();
        Themes.apply();
        this.render();
        toast('Papel de parede atualizado', 'image');
      } catch (e) { toast('Não foi possível salvar a imagem', 'close'); }
    }));
    if (Themes.customWallpaperUrl) {
      const rm = el('button', 'chip', 'Remover imagem');
      rm.addEventListener('click', async () => {
        await Files.del('customWallpaper');
        Themes.customWallpaperUrl = null;
        if (Store.state.appearance.wallpaper === 'custom') Store.state.appearance.wallpaper = 'aurora';
        Store.save();
        Themes.apply();
        this.render();
      });
      uploads.append(rm);
    }
    wpCtl.append(uploads);
    sec.append(wpCtl);

    const fontCtl = pCtl('<span>Fonte da interface</span>');
    Themes.ensureFonts(UI_FONTS.map(f => f.id));
    fontCtl.append(chipGroup(
      UI_FONTS.map(f => ({ id: f.id, label: f.label, cls: 'font-chip', style: { fontFamily: f.family } })),
      a.uiFont,
      (id) => {
        Store.state.appearance.uiFont = id;
        Themes.apply();
        Store.save();
        this.render();
      }
    ));
    sec.append(fontCtl);
    return sec;
  },

  /* ================= efeitos ================= */
  effectsSection() {
    const m = Store.state.motion;
    const p = Store.state.particles;
    const fx = Store.state.effects || (Store.state.effects = { level: 'full' });
    const sec = pSection('motion', 'Efeitos');

    sec.append(pSub('Desempenho'));
    sec.append(pCtl('<span>Nível de efeitos</span>'));
    sec.lastChild.append(chipGroup([
      { id: 'full',    label: 'Completos' },
      { id: 'reduced', label: 'Reduzidos' },
      { id: 'off',     label: 'Desligados' }
    ], fx.level || 'full', (id) => {
      fx.level = id;
      Motion.readState();
      Store.save();
      this.render();
    }));
    sec.append(el('p', 'panel-note', 'Reduzidos deixam o fundo mais discreto e econômico. Desligados param o movimento e as partículas — a Área de Trabalho já pausa tudo automaticamente.'));

    sec.append(pSub('Efeitos de movimento'));
    sec.append(switchRow('Movimento ativado', m.enabled, (on) => {
      Store.state.motion.enabled = on;
      Motion.readState();
      Store.save();
    }));
    sec.append(pCtl('<span>Estilo</span>'));
    sec.lastChild.append(chipGroup(MOTION_MODES, m.mode, (id) => {
      Store.state.motion.mode = id;
      Motion.readState();
      Store.save();
      this.render();
    }));
    sec.append(sliderRow('Intensidade', 0, 100, m.intensity, v => v + '%', v => {
      Store.state.motion.intensity = v;
      Motion.readState();
      Store.save();
    }));
    sec.append(sliderRow('Suavidade', 0, 100, m.smoothness, v => v + '%', v => {
      Store.state.motion.smoothness = v;
      Motion.readState();
      Store.save();
    }));
    sec.append(el('p', 'panel-note', 'Todos os estilos reagem ao mouse. Deslizar, Profundidade, Inclinação, Balanço e Deriva mudam a forma como o fundo acompanha o ponteiro.'));

    sec.append(pSub('Partículas'));
    sec.append(switchRow('Partículas ativadas', p.enabled, (on) => {
      Store.state.particles.enabled = on;
      Motion.readState();
      Store.save();
    }));
    sec.append(pCtl('<span>Estilo</span>'));
    sec.lastChild.append(chipGroup(PARTICLE_STYLES, p.style, (id) => {
      Store.state.particles.style = id;
      Motion.readState();
      Store.save();
      this.render();
    }));
    sec.append(sliderRow('Quantidade', 0, 100, p.amount, v => v + '%', v => {
      Store.state.particles.amount = v;
      Motion.readState();
      Store.save();
    }));
    sec.append(switchRow('Interagir com o mouse', p.interactive, (on) => {
      Store.state.particles.interactive = on;
      Motion.readState();
      Store.save();
    }));
    sec.append(el('p', 'panel-note', 'Chuva são gotas que caem e se desviam de leve do mouse. Onda são ondas circulares surgindo sozinhas, como gotas em um lago — o mouse não cria rastro, só perturba a onda quando ela o alcança. Poeira flutua, tela molhada escorre e neve deriva suavemente.'));
    return sec;
  },

  /* ================= cronômetro ================= */
  timerSection() {
    const t = Store.state.timer;
    const sec = pSection('timer', 'Cronômetro');
    const apply = (sync) => {
      TimerPage.applyConfig();
      if (sync) TimerPage.syncUI();
      Store.save();
    };

    sec.append(pSub('Versão'));
    const viewCtl = pCtl('<span>Estilo da página</span>');
    viewCtl.append(chipGroup([
      { id: 'classic', label: 'Clássica' },
      { id: 'focus', label: 'Minimalista' }
    ], t.view || 'classic', (id) => {
      Store.state.timer.view = id;
      apply(true);
      this.render();
    }));
    sec.append(viewCtl);
    sec.append(el('p', 'panel-note', 'Na versão minimalista fica apenas o relógio. Pressione o relógio e arraste: cima inicia ou pausa, direita reinicia, baixo troca o preset e esquerda alterna entre temporizador e cronômetro.'));

    sec.append(pSub('Número'));
    const fontCtl = pCtl('<span>Fonte</span>');
    Themes.ensureFonts(FONTS.map(f => f.id));
    fontCtl.append(chipGroup(
      FONTS.map(f => ({ id: f.id, label: f.label, cls: 'font-chip', style: { fontFamily: f.family } })),
      t.font,
      (id) => {
        Store.state.timer.font = id;
        apply();
        this.render();
      }
    ));
    sec.append(fontCtl);

    sec.append(sliderRow('Tamanho', 48, 160, t.size, v => v + 'px', v => {
      Store.state.timer.size = v;
      apply();
    }));
    sec.append(sliderRow('Peso da fonte', 200, 800, t.weight, v => String(v), v => {
      Store.state.timer.weight = v;
      apply();
    }, 100));
    sec.append(sliderRow('Espaçamento', 0, 20, t.tracking, v => (v / 100).toFixed(2) + 'em', v => {
      Store.state.timer.tracking = v;
      apply();
    }));

    const tintCtl = pCtl('<span>Cor do número</span>');
    const tintRow = el('div', 'color-row');
    const picker = el('input');
    picker.type = 'color';
    picker.value = t.tint || '#8fa2ff';
    picker.title = 'Cor personalizada';
    picker.addEventListener('input', () => {
      Store.state.timer.tint = picker.value;
      resetTint.classList.remove('active');
      apply();
    });
    const resetTint = el('button', 'chip' + (t.tint ? '' : ' active'), 'Cor do tema');
    resetTint.addEventListener('click', () => {
      Store.state.timer.tint = '';
      apply();
      this.render();
    });
    tintRow.append(picker, resetTint);
    tintCtl.append(tintRow);
    sec.append(tintCtl);

    const animCtl = pCtl('<span>Animação dos dígitos</span>');
    animCtl.append(chipGroup([
      { id: 'none', label: 'Nenhuma' },
      { id: 'flip', label: 'Flip' }
    ], t.digitAnim || 'none', (id) => {
      Store.state.timer.digitAnim = id;
      apply();
      this.render();
    }));
    sec.append(animCtl);
    sec.append(switchRow('Dois-pontos piscando', t.blink, (on) => {
      Store.state.timer.blink = on;
      apply();
    }));
    sec.append(switchRow('Mostrar rótulo', t.label, (on) => {
      Store.state.timer.label = on;
      apply();
    }));

    sec.append(pSub('Efeitos'));
    sec.append(switchRow('Brilho / neon', t.effectGlow, (on) => {
      Store.state.timer.effectGlow = on;
      apply();
    }));
    sec.append(sliderRow('Intensidade do brilho', 0, 100, t.glow, v => v === 0 ? 'desligado' : v + '%', v => {
      Store.state.timer.glow = v;
      apply();
    }));
    sec.append(switchRow('Sombra projetada', t.effectShadow, (on) => {
      Store.state.timer.effectShadow = on;
      apply();
    }));
    sec.append(switchRow('Contorno vazado', t.effectOutline, (on) => {
      Store.state.timer.effectOutline = on;
      apply();
    }));
    sec.append(switchRow('Pulsação suave', t.effectPulse, (on) => {
      Store.state.timer.effectPulse = on;
      apply();
    }));

    sec.append(pSub('Anel ao redor'));
    sec.append(switchRow('Anel de progresso', t.ring, (on) => {
      Store.state.timer.ring = on;
      apply();
    }));
    sec.append(sliderRow('Espessura do anel', 1, 12, t.ringWidth, v => v + 'px', v => {
      Store.state.timer.ringWidth = v;
      apply();
    }));
    const ringCtl = pCtl('<span>Estilo do anel</span>');
    ringCtl.append(chipGroup([
      { id: 'solid', label: 'Sólido' },
      { id: 'gradient', label: 'Gradiente' },
      { id: 'dashed', label: 'Tracejado' }
    ], t.ringStyle || 'solid', (id) => {
      Store.state.timer.ringStyle = id;
      apply();
      this.render();
    }));
    sec.append(ringCtl);

    sec.append(pSub('Atrás do número'));
    const backCtl = pCtl('<span>Elemento de fundo</span>');
    backCtl.append(chipGroup([
      { id: 'none', label: 'Nenhum' },
      { id: 'glass', label: 'Vidro' },
      { id: 'solid', label: 'Cartão' },
      { id: 'halo', label: 'Halo' }
    ], t.backdrop || 'none', (id) => {
      Store.state.timer.backdrop = id;
      apply();
      this.render();
    }));
    sec.append(backCtl);

    sec.append(pSub('Sessões e fundo'));
    sec.append(switchRow('Ciclo automático', t.autoCycle, (on) => {
      Store.state.timer.autoCycle = on;
      apply(true);
    }));
    sec.append(numRow('Focos antes da pausa longa', t.cycle, 2, 12, v => {
      Store.state.timer.cycle = v;
      apply(true);
    }));

    const durCtl = pCtl('<span>Durações (min)</span>');
    durCtl.append(numRow('Foco', t.durations.focus, 1, 180, v => {
      Store.state.timer.durations.focus = v;
      apply(true);
    }));
    durCtl.append(numRow('Pausa curta', t.durations.short, 1, 60, v => {
      Store.state.timer.durations.short = v;
      apply(true);
    }));
    durCtl.append(numRow('Pausa longa', t.durations.long, 1, 90, v => {
      Store.state.timer.durations.long = v;
      apply(true);
    }));
    durCtl.append(numRow('Personalizado', t.durations.custom, 1, 180, v => {
      Store.state.timer.durations.custom = v;
      apply(true);
    }));
    sec.append(durCtl);

    sec.append(sliderRow('Escurecimento do fundo', 0, 100, t.dim, v => v + '%', v => {
      Store.state.timer.dim = v;
      apply();
    }));
    sec.append(switchRow('Desfocar o fundo', t.blur, (on) => {
      Store.state.timer.blur = on;
      apply();
    }));
    sec.append(switchRow('Som ao finalizar', t.sound, (on) => {
      Store.state.timer.sound = on;
      Store.save();
    }));

    sec.append(pSub('Durante a inatividade'));
    sec.append(el('p', 'panel-note', 'Escolha o que continua visível no modo calmo. O relógio permanece sempre; na versão minimalista apenas ele é exibido.'));
    const idleDefs = [
      { id: 'ring',     label: 'Anel ao redor' },
      { id: 'label',    label: 'Rótulo do preset' },
      { id: 'tabs',     label: 'Abas temporizador/cronômetro' },
      { id: 'presets',  label: 'Botões de preset' },
      { id: 'sessions', label: 'Sessões de hoje' },
      { id: 'controls', label: 'Controles' },
      { id: 'hint',     label: 'Dica de atalhos' }
    ];
    t.idle = t.idle || {};
    idleDefs.forEach(d => {
      sec.append(switchRow(d.label, t.idle[d.id] !== false, (on) => {
        Store.state.timer.idle[d.id] = on;
        TimerPage.applyConfig();
        Store.save();
      }));
    });
    return sec;
  },

  /* botão que abre o editor direto na página */
  editOnScreen(page) {
    const b = el('button', 'chip', svgIcon('grip') + '<span>Editar na tela</span>');
    b.style.marginTop = '12px';
    b.addEventListener('click', () => {
      this.close();
      setTimeout(() => LayoutEdit.start(page), 300);
    });
    return b;
  },

  /* ================= editor de arrasto ================= */
  dragEditor(items, defs, onChange) {
    const list = el('div', 'drag-list');
    const lockedIndex = items.findIndex(x => x.locked);

    const persist = (arr) => {
      /* mantém o item fixo na mesma posição */
      if (lockedIndex >= 0) {
        const locked = arr.find(x => x.locked);
        if (locked) {
          const at = arr.indexOf(locked);
          if (at !== lockedIndex) {
            arr.splice(at, 1);
            arr.splice(clamp(lockedIndex, 0, arr.length), 0, locked);
          }
        }
      }
      onChange(arr);
    };

    items.forEach((item, idx) => {
      const def = defs.find(d => d.id === item.id) || { label: item.id };
      const row = el('div', 'drag-row' + (item.locked ? ' locked' : '') + (item.on ? '' : ' off'));
      row.draggable = !item.locked;
      row.dataset.id = item.id;
      row.append(el('span', 'drag-handle', item.locked ? svgIcon('lock') : svgIcon('grip')));
      row.append(el('span', 'drag-label', def.label));

      if (item.locked) {
        row.append(el('span', 'drag-fixed', 'fixo'));
      } else {
        const sw = el('button', 'switch' + (item.on ? ' on' : ''));
        sw.setAttribute('role', 'switch');
        sw.setAttribute('aria-checked', item.on ? 'true' : 'false');
        sw.title = item.on ? 'Ocultar' : 'Mostrar';
        sw.addEventListener('click', (e) => {
          e.stopPropagation();
          item.on = !item.on;
          sw.classList.toggle('on', item.on);
          sw.setAttribute('aria-checked', item.on ? 'true' : 'false');
          row.classList.toggle('off', !item.on);
          persist(items);
        });
        row.append(sw);

        const up = el('button', 'drag-move', svgIcon('chevU'));
        up.title = 'Mover para cima';
        up.addEventListener('click', (e) => {
          e.stopPropagation();
          if (idx === 0 || items[idx - 1].locked) return;
          const arr = items.slice();
          const tmp = arr[idx - 1]; arr[idx - 1] = arr[idx]; arr[idx] = tmp;
          persist(arr);
        });
        const down = el('button', 'drag-move', svgIcon('chevD'));
        down.title = 'Mover para baixo';
        down.addEventListener('click', (e) => {
          e.stopPropagation();
          if (idx === items.length - 1 || items[idx + 1].locked) return;
          const arr = items.slice();
          const tmp = arr[idx + 1]; arr[idx + 1] = arr[idx]; arr[idx] = tmp;
          persist(arr);
        });
        row.append(up, down);
      }

      if (!item.locked) {
        row.addEventListener('dragstart', (e) => {
          this._dragFrom = idx;
          row.classList.add('dragging');
          e.dataTransfer.effectAllowed = 'move';
          try { e.dataTransfer.setData('text/plain', String(idx)); } catch (err) { /* ignora */ }
        });
        row.addEventListener('dragend', () => {
          this._dragFrom = null;
          row.classList.remove('dragging');
          $$('.drag-row', list).forEach(r => r.classList.remove('over'));
        });
        row.addEventListener('dragover', (e) => {
          e.preventDefault();
          e.dataTransfer.dropEffect = 'move';
          row.classList.add('over');
        });
        row.addEventListener('dragleave', () => row.classList.remove('over'));
        row.addEventListener('drop', (e) => {
          e.preventDefault();
          row.classList.remove('over');
          const from = this._dragFrom;
          this._dragFrom = null;
          if (from == null || from < 0 || from === idx) return;
          const arr = items.slice();
          const moved = arr.splice(from, 1)[0];
          arr.splice(idx, 0, moved);
          persist(arr);
        });
      }

      list.append(row);
    });
    return list;
  },

  /* ================= início ================= */
  homeSection() {
    const sec = pSection('home', 'Tela inicial');
    sec.append(el('p', 'panel-note', 'Arraste pelo ícone para reordenar no painel, ou use o editor direto na tela para arrastar os próprios elementos. O relógio é fixo e não pode ser removido.'));
    const items = HomePage.layout();
    sec.append(this.dragEditor(items, HOME_LAYOUT, (arr) => {
      Store.state.home.layout = arr;
      Store.save();
      HomePage.applyLayout();
      this.render();
    }));
    sec.append(this.editOnScreen('home'));

    sec.append(pSub('Durante a inatividade'));
    sec.append(el('p', 'panel-note', 'Escolha o que continua visível quando o modo calmo entra em ação.'));
    HomePage.layout().forEach(item => {
      const def = HOME_LAYOUT.find(d => d.id === item.id) || { label: item.id };
      sec.append(switchRow(def.label, item.idle !== false, (on) => {
        const arr = HomePage.layout();
        const target = arr.find(x => x.id === item.id);
        if (target) target.idle = on;
        Store.state.home.layout = arr;
        Store.save();
        HomePage.applyLayout();
      }));
    });

    const reset = el('button', 'chip', 'Restaurar layout padrão');
    reset.style.marginTop = '12px';
    reset.addEventListener('click', () => {
      Store.state.home.layout = Store.defaults().home.layout;
      Store.save();
      HomePage.applyLayout();
      this.render();
    });
    sec.append(reset);
    return sec;
  },

  /* ================= atalhos ================= */
  shortcutsSection() {
    const sec = pSection('grid', 'Atalhos');
    sec.append(el('p', 'panel-note', 'Escolha os atalhos da tela inicial, a ordem em que aparecem e quais ficam visíveis.'));
    const chipsItems = HomePage.chipsLayout();
    sec.append(this.dragEditor(chipsItems, HOME_CHIP_DEFS, (arr) => {
      Store.state.home.chips = arr;
      Store.save();
      HomePage.renderChips();
      this.render();
    }));

    const reset = el('button', 'chip', 'Restaurar atalhos padrão');
    reset.style.marginTop = '12px';
    reset.addEventListener('click', () => {
      Store.state.home.chips = Store.defaults().home.chips;
      Store.save();
      HomePage.renderChips();
      this.render();
    });
    sec.append(reset);
    return sec;
  },

  /* ================= estatísticas ================= */
  trackerSection() {
    const tr = Store.state.tracker;
    const sec = pSection('chart', 'Estatísticas');

    sec.append(pSub('Elementos da página'));
    sec.append(el('p', 'panel-note', 'Arraste pelo ícone para reordenar e use o interruptor para mostrar ou ocultar cada bloco — ou edite direto na tela.'));
    const items = TrackerPage.layout();
    sec.append(this.dragEditor(items, TRACKER_LAYOUT, (arr) => {
      Store.state.tracker.layout = arr;
      Store.save();
      TrackerPage.applyLayout();
      this.render();
    }));
    sec.append(this.editOnScreen('tracker'));

    sec.append(pSub('Cartões de estatísticas (até 8)'));
    sec.append(el('p', 'panel-note', 'Escolha quais cartões exibir, a ordem e o tamanho de cada um (1x quadrado ou 2x largo):'));
    const wList = el('div', 'drag-list');
    const widgets = TrackerPage.widgets();
    widgets.forEach((item, idx) => {
      const def = TRACKER_WIDGET_DEFS.find(d => d.id === item.id) || { label: item.id };
      const row = el('div', 'drag-row' + (item.on ? '' : ' off'));
      row.append(el('span', 'drag-handle', svgIcon(def.icon || 'chart')));
      row.append(el('span', 'drag-label', def.label));

      const sizeBtn = el('button', 'chip' + (item.size === '2x' ? ' active' : ''), item.size === '2x' ? '2x' : '1x');
      sizeBtn.style.padding = '3px 8px';
      sizeBtn.style.fontSize = '11px';
      sizeBtn.title = 'Alternar tamanho: 1x (quadrado) ou 2x (largo)';
      sizeBtn.addEventListener('click', () => {
        item.size = item.size === '2x' ? '1x' : '2x';
        sizeBtn.textContent = item.size;
        sizeBtn.classList.toggle('active', item.size === '2x');
        Store.state.tracker.widgets = widgets;
        Store.save();
        TrackerPage.render();
      });
      row.append(sizeBtn);

      const sw = el('button', 'switch' + (item.on ? ' on' : ''));
      sw.setAttribute('role', 'switch');
      sw.setAttribute('aria-checked', item.on ? 'true' : 'false');
      sw.title = item.on ? 'Ocultar' : 'Mostrar';
      sw.addEventListener('click', () => {
        item.on = !item.on;
        sw.classList.toggle('on', item.on);
        sw.setAttribute('aria-checked', item.on ? 'true' : 'false');
        row.classList.toggle('off', !item.on);
        Store.state.tracker.widgets = widgets;
        Store.save();
        TrackerPage.render();
      });
      row.append(sw);

      const up = el('button', 'drag-move', svgIcon('chevU'));
      up.title = 'Mover para cima';
      up.addEventListener('click', () => {
        if (idx === 0) return;
        const arr = widgets.slice();
        const tmp = arr[idx - 1]; arr[idx - 1] = arr[idx]; arr[idx] = tmp;
        Store.state.tracker.widgets = arr;
        Store.save();
        TrackerPage.render();
        this.render();
      });
      const down = el('button', 'drag-move', svgIcon('chevD'));
      down.title = 'Mover para baixo';
      down.addEventListener('click', () => {
        if (idx === widgets.length - 1) return;
        const arr = widgets.slice();
        const tmp = arr[idx + 1]; arr[idx + 1] = arr[idx]; arr[idx] = tmp;
        Store.state.tracker.widgets = arr;
        Store.save();
        TrackerPage.render();
        this.render();
      });
      row.append(up, down);
      wList.append(row);
    });
    sec.append(wList);

    const reset = el('button', 'chip', 'Restaurar ordem e cartões padrão');
    reset.style.marginTop = '12px';
    reset.addEventListener('click', () => {
      Store.state.tracker.layout = Store.defaults().tracker.layout;
      Store.state.tracker.widgets = Store.defaults().tracker.widgets;
      Store.state.tracker.chart2 = Store.defaults().tracker.chart2;
      Store.state.tracker.goalStyle = 'bar';
      Store.save();
      TrackerPage.applyLayout();
      TrackerPage.renderControls();
      TrackerPage.render();
      this.render();
    });
    sec.append(reset);

    sec.append(pSub('Gráfico principal'));
    const typeCtl = pCtl('<span>Visual</span>');
    typeCtl.append(chipGroup(
      TRACKER_TYPES.map(t => ({ id: t.id, label: t.label })),
      tr.chart,
      (id) => {
        Store.state.tracker.chart = id;
        Store.save();
        TrackerPage.renderControls();
        TrackerPage.renderChart();
        this.render();
      }
    ));
    sec.append(typeCtl);

    const periodCtl = pCtl('<span>Período</span>');
    periodCtl.append(chipGroup(
      TRACKER_PERIODS.map(p => ({ id: String(p), label: p === 365 ? '1 ano' : p + ' dias' })),
      String(tr.period),
      (id) => {
        Store.state.tracker.period = +id;
        if (+id !== 365) Store.state.tracker.yearOffset = 0;
        Store.save();
        TrackerPage.renderControls();
        TrackerPage.renderChart();
        this.render();
      }
    ));
    sec.append(periodCtl);

    sec.append(pSub('Heatmaps'));
    sec.append(sliderRow('Tamanho das células', 10, 34, tr.heatCell || 18, v => v + 'px', v => {
      Store.state.tracker.heatCell = v;
      Store.save();
      TrackerPage.renderChart();
    }));
    sec.append(el('p', 'panel-note', 'Vale para o heatmap em grade e para o circular. A intensidade da cor acompanha o tempo de estudo de cada dia.'));

    sec.append(pSub('Segundo gráfico'));
    const c2 = tr.chart2 = tr.chart2 || { on: false, chart: 'ring', period: 365, yearOffset: 0, metric: 'focus' };
    c2.on = TrackerPage.chart2On();
    sec.append(switchRow('Exibir segundo gráfico', c2.on, (on) => {
      c2.on = on;
      const arr = TrackerPage.layout();
      const target = arr.find(x => x.id === 'chart2');
      if (target) target.on = on;
      Store.state.tracker.layout = arr;
      Store.save();
      TrackerPage.applyLayout();
      TrackerPage.renderControls();
      TrackerPage.renderChart2();
      this.render();
    }));
    if (c2.on) {
      const metricCtl = pCtl('<span>Métrica do segundo gráfico</span>');
      metricCtl.append(chipGroup([
        { id: 'focus', label: 'Sessões de foco' },
        { id: 'hours', label: 'Horas de uso' }
      ], c2.metric || 'focus', (id) => {
        c2.metric = id;
        Store.save();
        TrackerPage.renderControls();
        TrackerPage.renderChart2();
        this.render();
      }));
      sec.append(metricCtl);

      const typeCtl2 = pCtl('<span>Visual do segundo gráfico</span>');
      typeCtl2.append(chipGroup(
        TRACKER_TYPES.map(t => ({ id: t.id, label: t.label })),
        c2.chart,
        (id) => {
          c2.chart = id;
          Store.save();
          TrackerPage.renderControls();
          TrackerPage.renderChart2();
          this.render();
        }
      ));
      sec.append(typeCtl2);

      const periodCtl2 = pCtl('<span>Período do segundo gráfico</span>');
      periodCtl2.append(chipGroup(
        TRACKER_PERIODS.map(p => ({ id: String(p), label: p === 365 ? '1 ano' : p + ' dias' })),
        String(c2.period),
        (id) => {
          c2.period = +id;
          if (+id !== 365) c2.yearOffset = 0;
          Store.save();
          TrackerPage.renderControls();
          TrackerPage.renderChart2();
          this.render();
        }
      ));
      sec.append(periodCtl2);
    }

    sec.append(pSub('Meta diária'));
    const goalStyleCtl = pCtl('<span>Estilo da meta</span>');
    goalStyleCtl.append(chipGroup([
      { id: 'bar',        label: 'Barra contínua' },
      { id: 'ring',       label: 'Medidor circular' },
      { id: 'milestones', label: 'Com marcos (25%-100%)' }
    ], tr.goalStyle || 'bar', (id) => {
      Store.state.tracker.goalStyle = id;
      Store.save();
      TrackerPage.render();
      this.render();
    }));
    sec.append(goalStyleCtl);

    const goalCtl = pCtl('<span>Horas por dia</span>');
    goalCtl.append(numRow('Horas por dia', tr.goal, 0, 16, v => {
      Store.state.tracker.goal = v;
      Store.save();
      TrackerPage.render();
    }));
    sec.append(goalCtl);
    return sec;
  },

  /* ================= tarefas ================= */
  tasksSection() {
    const cfg = Store.state.tasks;
    const sec = pSection('tasks', 'Tarefas');
    const ACCENTS = [
      { id: '', label: 'Tema', color: 'var(--accent)' },
      { id: '#ff7a59', label: 'Coral', color: '#ff7a59' },
      { id: '#4ecb9d', label: 'Menta', color: '#4ecb9d' },
      { id: '#58b7ff', label: 'Céu', color: '#58b7ff' },
      { id: '#a78bfa', label: 'Violeta', color: '#a78bfa' },
      { id: '#f2b84b', label: 'Ouro', color: '#f2b84b' },
      { id: '#f472b6', label: 'Rosa', color: '#f472b6' }
    ];
    const ctl = pCtl('<span>Cor de destaque</span>');
    const grid = el('div', 'accent-grid');
    ACCENTS.forEach(c => {
      const dot = el('button', 'accent-dot' + (cfg.accent === c.id ? ' active' : ''));
      dot.style.background = c.color;
      dot.title = c.label;
      dot.addEventListener('click', () => {
        Store.state.tasks.accent = c.id;
        TasksPage.applyConfig();
        Store.save();
        this.render();
      });
      grid.append(dot);
    });
    const picker = el('input');
    picker.type = 'color';
    picker.value = cfg.accent || '#8fa2ff';
    picker.title = 'Cor personalizada';
    picker.addEventListener('input', () => {
      Store.state.tasks.accent = picker.value;
      TasksPage.applyConfig();
      Store.save();
    });
    grid.append(picker);
    ctl.append(grid);
    sec.append(ctl);

    const sortCtl = pCtl('<span>Ordenação</span>');
    sortCtl.append(chipGroup([
      { id: 'recent', label: 'Recentes' },
      { id: 'oldest', label: 'Antigas' },
      { id: 'alpha', label: 'A–Z' }
    ], cfg.sort, (id) => {
      Store.state.tasks.sort = id;
      Store.save();
      TasksPage.render();
      this.render();
    }));
    sec.append(sortCtl);

    const animCtl = pCtl('<span>Animação ao adicionar</span>');
    animCtl.append(chipGroup([
      { id: 'slide', label: 'Deslizar' },
      { id: 'fade', label: 'Suave' },
      { id: 'pop', label: 'Pop' }
    ], cfg.anim, (id) => {
      Store.state.tasks.anim = id;
      TasksPage.applyConfig();
      Store.save();
      this.render();
    }));
    sec.append(animCtl);

    sec.append(switchRow('Concluídas ao final da lista', cfg.doneLast, (on) => {
      Store.state.tasks.doneLast = on;
      Store.save();
      TasksPage.render();
    }));
    sec.append(switchRow('Som ao concluir', cfg.popSound, (on) => {
      Store.state.tasks.popSound = on;
      Store.save();
    }));
    sec.append(el('p', 'panel-note', 'Dica: dê um duplo clique no texto ou use o lápis para editar uma tarefa.'));
    return sec;
  },

  /* ================= geral ================= */
  generalSection() {
    const sec = pSection('sliders', 'Geral');

    sec.append(pSub('Modo calmo'));
    sec.append(el('p', 'panel-note', 'Depois de um tempo sem atividade, os detalhes somem. Em Progresso e Tarefas fica apenas um ícone discreto; na tela inicial, o relógio permanece.'));
    const idleCtl = pCtl('<span>Esconder detalhes após</span>');
    idleCtl.append(chipGroup([
      { id: '30', label: '30s' },
      { id: '60', label: '1min' },
      { id: '120', label: '2min' },
      { id: '300', label: '5min' },
      { id: '0', label: 'Desligado' }
    ], String(Store.state.idle.timeout), (id) => {
      Store.state.idle.timeout = +id;
      Store.save();
      Idle.apply();
      this.render();
    }));
    sec.append(idleCtl);

    sec.append(pSub('Bolinha de navegação'));
    sec.append(el('p', 'panel-note', 'A bolinha pode ser arrastada para 8 posições: centro inferior e superior, os quatro cantos e o meio das laterais. Perto das bordas direitas, o painel abre pela esquerda.'));
    sec.append(switchRow('Expandir ao passar o mouse', !!(Store.state.dock && Store.state.dock.hover), (on) => {
      Store.state.dock.hover = on;
      Store.save();
      if (!on && Router.hovering) {
        Router.hovering = false;
        Router.toggleDock(false);
      }
    }));

    sec.append(pSub('Música de fundo'));
    const m = Store.state.music;
    const hasCustom = !!(Sound.bgm && Sound.bgm.src);
    const opts = [
      { id: 'none', label: 'Sem música' },
      { id: 'rain', label: 'Chuva' },
      { id: 'ocean', label: 'Oceano' },
      { id: 'pad', label: 'Ambiente' },
      { id: 'lofi', label: 'Lo-fi' }
    ];
    if (hasCustom) opts.push({ id: 'custom', label: 'Sua música' });
    const musicCtl = pCtl('<span>Trilha</span>');
    musicCtl.append(chipGroup(opts, m.track, (id) => {
      Store.state.music.track = id;
      Store.save();
      if (id === 'none') Sound.stop();
      else Sound.play(id);
      this.render();
    }));
    sec.append(musicCtl);
    sec.append(sliderRow('Volume', 0, 100, Math.round(m.volume * 100), v => v + '%', v => Sound.setVolume(v / 100)));
    const up = el('div', 'chip-grid');
    up.style.marginTop = '12px';
    up.append(uploadBtn(hasCustom ? 'Trocar arquivo' : 'Enviar música', 'audio/*', async (file) => {
      if (!file.type.startsWith('audio/')) { toast('Escolha um arquivo de áudio', 'close'); return; }
      if (file.size > 12 * 1024 * 1024) { toast('Áudio muito grande (máx. 12 MB)', 'close'); return; }
      try {
        const url = await readFileAsDataURL(file);
        await Files.put('customMusic', url);
        Sound.setCustomSource(url);
        Store.state.music.track = 'custom';
        Store.save();
        Sound.play('custom');
        this.render();
        toast('Música carregada', 'music');
      } catch (e) { toast('Não foi possível salvar o áudio', 'close'); }
    }));
    sec.append(up);
    sec.append(el('p', 'panel-note', 'Trilhas geradas em tempo real, sem arquivos externos.'));

    sec.append(pSub('Dados'));
    sec.append(el('p', 'panel-note',
      Usage.daysUsed() + ' dias · ' + fmtHours(Usage.totalSeconds()) + ' de uso · ' +
      Store.state.tracker.tasksCompleted + ' tarefas realizadas.'));
    const exportBtn = el('button', 'chip', svgIcon('download') + '<span>Exportar dados (JSON)</span>');
    exportBtn.style.marginTop = '8px';
    exportBtn.addEventListener('click', () => TrackerPage.exportData());
    sec.append(exportBtn);

    const btn = el('button', 'danger-btn', 'Apagar todos os dados');
    btn.style.marginTop = '14px';
    btn.addEventListener('click', () => this.resetAll());
    sec.append(btn);
    return sec;
  },

  resetAll() {
    if (!confirm('Apagar todos os dados do Fluxo?\nIsso inclui tarefas, progresso, quadro e personalizações.')) return;
    try {
      localStorage.removeItem(STORE_KEY);
      Object.keys(localStorage)
        .filter(k => k.startsWith('fluxo-file-') || k.startsWith('fluxo-ws-'))
        .forEach(k => localStorage.removeItem(k));
    } catch (e) { /* ignora */ }
    try {
      if (Files.db) Files.db.close();
      indexedDB.deleteDatabase('fluxo-files');
    } catch (e) { /* ignora */ }

    const reload = () => setTimeout(() => location.reload(), 150);
    try {
      if (typeof WorkspaceDB !== 'undefined') {
        WorkspaceDB.clearAll().then(() => {
          try { indexedDB.deleteDatabase('fluxo-workspace'); } catch (e) { /* ignora */ }
          reload();
        }).catch(reload);
        return;
      }
    } catch (e) { /* ignora */ }
    reload();
  }
};
