'use strict';
/* ============ workspace.js — Área de Trabalho (quadro infinito) ============ */

const WS_DB_NAME = 'fluxo-workspace';
const WS_BOARD_KEY = 'board';

/* cursores do quadro: pontos e mira são SVGs locais (ponto ativo no centro); mão e ponteiro são nativos */
const WS_CURSORS = [
  { id: 'dot-s',   group: 'dots',   kind: 'dot',  size: 10, label: 'Ponto pequeno', short: 'P' },
  { id: 'dot-m',   group: 'dots',   kind: 'dot',  size: 16, label: 'Ponto médio',   short: 'M' },
  { id: 'dot-l',   group: 'dots',   kind: 'dot',  size: 26, label: 'Ponto grande',  short: 'G' },
  { id: 'prec-s',  group: 'prec',   kind: 'prec', size: 22, label: 'Precisão pequena', short: 'P' },
  { id: 'prec-m',  group: 'prec',   kind: 'prec', size: 32, label: 'Precisão média',   short: 'M' },
  { id: 'prec-l',  group: 'prec',   kind: 'prec', size: 46, label: 'Precisão grande',  short: 'G' },
  { id: 'grab',    group: 'native', kind: 'native', css: 'grab',    label: 'Mão',      short: 'Mão' },
  { id: 'pointer', group: 'native', kind: 'native', css: 'pointer', label: 'Ponteiro', short: 'Ponteiro' }
];
const WS_CURSOR_GROUPS = [
  { id: 'dots',   label: 'Pontos' },
  { id: 'prec',   label: 'Precisão' },
  { id: 'native', label: 'Mão e ponteiro' }
];
const WS_CURSOR_DEFAULT = 'dot-m';
/* ids da lista antiga que ainda podem estar salvos no navegador */
const WS_CURSOR_ALIASES = { default: 'dot-m', crosshair: 'prec-m', 'zoom-in': 'dot-m', text: 'dot-m', move: 'dot-m' };

function wsNormCursor(id) {
  if (WS_CURSORS.some(c => c.id === id)) return id;
  return WS_CURSOR_ALIASES[id] || WS_CURSOR_DEFAULT;
}

/* desenho (SVG) do cursor; cada traço tem um contorno escuro para aparecer em fundos claros e escuros */
function wsCursorSvg(c, previewPx) {
  const pad = 3;
  const W = c.size + pad * 2;
  const m = W / 2;
  let inner;
  if (c.kind === 'dot') {
    inner = '<circle cx="' + m + '" cy="' + m + '" r="' + (c.size / 2) + '" fill="#fff" stroke="rgba(0,0,0,.6)" stroke-width="1.5"/>';
  } else {
    const r = c.size * 0.27;
    const far = c.size / 2;
    const near = r + c.size * 0.04;
    const ticks =
      'M' + m + ' ' + (m - far) + 'V' + (m - near) + 'M' + m + ' ' + (m + far) + 'V' + (m + near) +
      'M' + (m - far) + ' ' + m + 'H' + (m - near) + 'M' + (m + far) + ' ' + m + 'H' + (m + near);
    inner =
      '<g fill="none" stroke-linecap="round">' +
        '<circle cx="' + m + '" cy="' + m + '" r="' + r + '" stroke="rgba(0,0,0,.6)" stroke-width="3.4"/>' +
        '<path d="' + ticks + '" stroke="rgba(0,0,0,.6)" stroke-width="3.4"/>' +
        '<circle cx="' + m + '" cy="' + m + '" r="' + r + '" stroke="#fff" stroke-width="1.6"/>' +
        '<path d="' + ticks + '" stroke="#fff" stroke-width="1.6"/>' +
      '</g>' +
      '<circle cx="' + m + '" cy="' + m + '" r="1.3" fill="#fff" stroke="rgba(0,0,0,.6)" stroke-width=".8"/>';
  }
  const px = previewPx ? ' width="' + previewPx + '" height="' + previewPx + '"' : ' width="' + W + '" height="' + W + '"';
  return '<svg xmlns="http://www.w3.org/2000/svg"' + px + ' viewBox="0 0 ' + W + ' ' + W + '">' + inner + '</svg>';
}

function wsCursorCss(id) {
  const c = WS_CURSORS.find(x => x.id === wsNormCursor(id));
  if (!c) return '';
  if (c.kind === 'native') return c.css;
  const hot = Math.round((c.size + 6) / 2);
  return 'url("data:image/svg+xml,' + encodeURIComponent(wsCursorSvg(c)) + '") ' + hot + ' ' + hot + ', ' + (c.kind === 'prec' ? 'crosshair' : 'default');
}

const WS_BG_SWATCHES = ['', '#0b0f1a', '#121826', '#1b1b24', '#22252e', '#f4f1ea', '#e9eef7', '#dce8e4', '#f3e6df'];

const WS_HL_COLORS = [
  { id: 'yellow', label: 'Amarelo', value: '#ffd84d' },
  { id: 'green',  label: 'Verde',   value: '#7ee787' },
  { id: 'blue',   label: 'Azul',    value: '#7cc4ff' },
  { id: 'pink',   label: 'Rosa',    value: '#ff9ecb' },
  { id: 'orange', label: 'Laranja', value: '#ffb86b' }
];

const WS_TIMER_STYLES = [
  { id: 'minimal', label: 'Minimalista' },
  { id: 'ring',    label: 'Circular' },
  { id: 'flip',    label: 'Flip' }
];

const WS_TIMER_COLORS = [
  { label: 'Tema',  value: '' },
  { label: 'Azul',  value: '#8fa2ff' },
  { label: 'Verde', value: '#5fe3c4' },
  { label: 'Âmbar', value: '#ffd166' },
  { label: 'Rosa',  value: '#ff8fa3' },
  { label: 'Lilás', value: '#c792ea' },
  { label: 'Neve',  value: '#f2f5ff' }
];

function wsNum(v, fallback) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function wsColor(v, fallback) {
  return /^#[0-9a-f]{3,8}$/i.test(String(v || '')) ? v : (fallback || '');
}

function wsEscape(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* ============ banco próprio do quadro ============ */
const WorkspaceDB = {
  db: null,
  opening: null,
  fallback: false,

  open() {
    if (this.db) return Promise.resolve(this.db);
    if (this.opening) return this.opening;
    this.opening = new Promise((resolve) => {
      let req;
      try { req = indexedDB.open(WS_DB_NAME, 1); }
      catch (e) { this.fallback = true; return resolve(null); }
      if (!req) { this.fallback = true; return resolve(null); }
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta');
        if (!db.objectStoreNames.contains('files')) db.createObjectStore('files');
      };
      req.onsuccess = () => { this.db = req.result; resolve(this.db); };
      req.onerror = () => { this.fallback = true; resolve(null); };
      setTimeout(() => { if (!this.db && !this.fallback) { this.fallback = true; resolve(null); } }, 1800);
    });
    return this.opening;
  },

  getMeta(key) {
    return this.open().then((db) => {
      if (!db) {
        try { return JSON.parse(localStorage.getItem('fluxo-ws-' + key) || 'null'); }
        catch (e) { return null; }
      }
      return new Promise((resolve) => {
        try {
          const tx = db.transaction('meta', 'readonly');
          const rq = tx.objectStore('meta').get(key);
          rq.onsuccess = () => resolve(rq.result == null ? null : rq.result);
          rq.onerror = () => resolve(null);
        } catch (e) { resolve(null); }
      });
    });
  },

  setMeta(key, value) {
    return this.open().then((db) => {
      if (!db) {
        try { localStorage.setItem('fluxo-ws-' + key, JSON.stringify(value)); } catch (e) { /* ignora */ }
        return;
      }
      return new Promise((resolve, reject) => {
        try {
          const tx = db.transaction('meta', 'readwrite');
          tx.objectStore('meta').put(value, key);
          tx.oncomplete = () => resolve();
          tx.onerror = () => reject(tx.error || new Error('idb'));
        } catch (e) { reject(e); }
      });
    });
  },

  getFile(key) {
    return this.open().then((db) => {
      if (!db) return null;
      return new Promise((resolve) => {
        try {
          const tx = db.transaction('files', 'readonly');
          const rq = tx.objectStore('files').get(key);
          rq.onsuccess = () => resolve(rq.result == null ? null : rq.result);
          rq.onerror = () => resolve(null);
        } catch (e) { resolve(null); }
      });
    });
  },

  putFile(key, value) {
    return this.open().then((db) => {
      if (!db) throw new Error('sem banco');
      return new Promise((resolve, reject) => {
        try {
          const tx = db.transaction('files', 'readwrite');
          tx.objectStore('files').put(value, key);
          tx.oncomplete = () => resolve();
          tx.onerror = () => reject(tx.error || new Error('idb'));
        } catch (e) { reject(e); }
      });
    });
  },

  delFile(key) {
    return this.open().then((db) => {
      if (!db) return;
      try {
        const tx = db.transaction('files', 'readwrite');
        tx.objectStore('files').delete(key);
      } catch (e) { /* ignora */ }
    });
  },

  clearAll() {
    return this.open().then((db) => {
      if (db) {
        try {
          const tx = db.transaction(['meta', 'files'], 'readwrite');
          tx.objectStore('meta').clear();
          tx.objectStore('files').clear();
        } catch (e) { /* ignora */ }
        try { db.close(); } catch (e) { /* ignora */ }
      }
      try { localStorage.removeItem('fluxo-ws-' + WS_BOARD_KEY); } catch (e) { /* ignora */ }
      this.db = null;
      this.opening = null;
    });
  }
};

/* ============ estado e utilidades do quadro ============ */
const Workspace = {
  inited: false,
  initPromise: null,
  loaded: false,
  entered: false,
  board: null,
  bgUrl: null,

  els: {},
  cardEls: new Map(),
  arrowEls: new Map(),
  pdfDocs: new Map(),
  pdfPromises: new Map(),
  pdfTasks: new Map(),
  pdfTokens: new Map(),
  pdfRendered: new Map(),
  pdfPageDims: new Map(),

  selCard: null,
  selArrow: null,
  linkFrom: null,
  popover: null,
  selection: null,

  panning: null,
  cardDrag: null,
  cardResize: null,
  timerDrag: null,
  pdfPress: null,
  selDrag: null,
  dragGhost: null,

  saveTimer: null,
  timerIv: null,
  pdfRefreshTimer: null,
  pdfLibPromise: null,
  lastTimerText: '',
  timerChars: [],
  fontsHooked: false,
  needsCenterView: false,

  /* -------- modelo -------- */
  defaultBoard() {
    return {
      v: 1,
      bg: { color: '', image: false },
      cursor: WS_CURSOR_DEFAULT,
      view: { x: 0, y: 0, scale: 1 },
      cards: [],
      arrows: [],
      pdfs: [],
      timer: {
        x: null, y: null, min: false, visible: true,
        style: 'ring', color: '', font: 'inter', size: 34, opacity: 100
      }
    };
  },

  normalize(raw) {
    const def = this.defaultBoard();
    const b = Object.assign({}, def);
    if (!raw || typeof raw !== 'object') return b;

    b.bg = Object.assign({}, def.bg, raw.bg || {});
    b.bg.color = wsColor(b.bg.color, '');
    b.bg.image = !!b.bg.image;
    b.cursor = wsNormCursor(raw.cursor);

    const view = raw.view || {};
    b.view = {
      x: wsNum(view.x, def.view.x),
      y: wsNum(view.y, def.view.y),
      scale: clamp(wsNum(view.scale, 1), 0.2, 2.6)
    };

    b.timer = Object.assign({}, def.timer, raw.timer || {});
    b.timer.style = WS_TIMER_STYLES.some(s => s.id === b.timer.style) ? b.timer.style : 'ring';
    b.timer.color = wsColor(b.timer.color, '');
    b.timer.font = (typeof FONTS !== 'undefined' && FONTS.some(f => f.id === b.timer.font)) ? b.timer.font : 'inter';
    b.timer.size = clamp(wsNum(b.timer.size, 34), 20, 72);
    b.timer.opacity = clamp(wsNum(b.timer.opacity, 100), 20, 100);
    b.timer.x = b.timer.x == null ? null : wsNum(b.timer.x, null);
    b.timer.y = b.timer.y == null ? null : wsNum(b.timer.y, null);
    b.timer.visible = b.timer.visible !== false;
    b.timer.min = !!b.timer.min;

    b.pdfs = (Array.isArray(raw.pdfs) ? raw.pdfs : [])
      .filter(p => p && p.id)
      .map(p => ({
        id: String(p.id),
        name: String(p.name || 'PDF'),
        size: wsNum(p.size, 0),
        pages: Math.max(0, wsNum(p.pages, 0)),
        highlights: (Array.isArray(p.highlights) ? p.highlights : [])
          .filter(h => h && h.page)
          .map(h => ({
            id: String(h.id || uid()),
            page: Math.max(1, wsNum(h.page, 1)),
            color: wsColor(h.color, WS_HL_COLORS[0].value),
            text: String(h.text || ''),
            rects: (Array.isArray(h.rects) ? h.rects : []).filter(r => r)
              .map(r => ({
                x: clamp(wsNum(r.x, 0), 0, 1),
                y: clamp(wsNum(r.y, 0), 0, 1),
                w: clamp(wsNum(r.w, 0), 0, 1),
                h: clamp(wsNum(r.h, 0), 0, 1)
              }))
          }))
      }));

    const pdfIds = new Set(b.pdfs.map(p => p.id));
    b.cards = (Array.isArray(raw.cards) ? raw.cards : [])
      .filter(c => c && c.id && (c.type === 'note' || c.type === 'pdf'))
      .filter(c => c.type !== 'pdf' || pdfIds.has(String(c.pdfId)))
      .map(c => {
        const card = {
          id: String(c.id),
          type: c.type === 'pdf' ? 'pdf' : 'note',
          x: wsNum(c.x, 0),
          y: wsNum(c.y, 0),
          w: clamp(wsNum(c.w, c.type === 'pdf' ? 360 : 280), 190, 2400),
          h: clamp(wsNum(c.h, c.type === 'pdf' ? 460 : 170), 96, 2400)
        };
        if (card.type === 'pdf') {
          card.pdfId = String(c.pdfId);
          card.page = Math.max(1, wsNum(c.page, 1));
        } else {
          card.text = typeof c.text === 'string' ? c.text : '';
          card.source = c.source && c.source.pdfId ? {
            pdfId: String(c.source.pdfId),
            page: Math.max(1, wsNum(c.source.page, 1))
          } : null;
        }
        return card;
      });

    const cardIds = new Set(b.cards.map(c => c.id));
    const seen = new Set();
    b.arrows = (Array.isArray(raw.arrows) ? raw.arrows : [])
      .filter(a => a && a.from && a.to && a.from !== a.to)
      .filter(a => cardIds.has(String(a.from)) && cardIds.has(String(a.to)))
      .filter(a => {
        const k = a.from + '>' + a.to;
        if (seen.has(k)) return false;
        seen.add(k);
        return true;
      })
      .map(a => ({ id: String(a.id || uid()), from: String(a.from), to: String(a.to) }));

    return b;
  },

  async load() {
    let raw = null;
    try { raw = await WorkspaceDB.getMeta(WS_BOARD_KEY); } catch (e) { raw = null; }
    this.board = this.normalize(raw);
    try { this.bgUrl = await WorkspaceDB.getFile('bg'); } catch (e) { this.bgUrl = null; }
    if (!raw || !raw.view) {
      const r = this.els.viewport.getBoundingClientRect();
      if (r.width > 40 && r.height > 40) {
        this.board.view = { x: r.width / 2, y: r.height / 2, scale: 1 };
      } else {
        this.needsCenterView = true;
      }
    }
    this.loaded = true;
  },

  scheduleSave() {
    if (!this.loaded) return;
    clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => this.flushSave(), 240);
  },

  flushSave() {
    clearTimeout(this.saveTimer);
    this.saveTimer = null;
    if (!this.loaded || !this.board) return;
    WorkspaceDB.setMeta(WS_BOARD_KEY, this.board).catch(() => {
      toast('Não foi possível salvar o quadro', 'close');
    });
  },

  /* -------- inicialização -------- */
  async init() {
    if (this.initPromise) return this.initPromise;
    this.initPromise = (async () => {
      this.cacheEls();
      this.buildEmpty();
      this.buildTopbar();
      this.buildZoom();
      this.buildTimer();
      this.bindEvents();
      await WorkspaceDB.open().catch(() => null);
      await this.load();
      this.renderAll();
      this.applyView();
      this.applyBg();
      this.applyCursor();
      this.renderTimer();
      this.updateEmpty();
      this.inited = true;
    })();
    return this.initPromise;
  },

  cacheEls() {
    this.els = {
      shell: $('#ws-shell'),
      viewport: $('#ws-viewport'),
      world: $('#ws-world'),
      arrows: $('#ws-arrows'),
      arrowLayer: $('#ws-arrow-layer'),
      empty: $('#ws-empty'),
      topbar: $('#ws-topbar'),
      zoom: $('#ws-zoom'),
      popovers: $('#ws-popovers'),
      timerRoot: $('#ws-timer-root'),
      selTools: $('#ws-sel-tools'),
      drop: $('#ws-drop'),
      fileBg: $('#ws-file-bg'),
      filePdf: $('#ws-file-pdf')
    };
  },

  async enter() {
    await this.init();
    if (this.entered) return;
    if (typeof Router !== 'undefined' && Router.route !== 'workspace') return;
    this.entered = true;
    if (this.needsCenterView) {
      const r = this.els.viewport.getBoundingClientRect();
      this.board.view = { x: r.width / 2, y: r.height / 2, scale: 1 };
      this.needsCenterView = false;
      this.scheduleSave();
    }
    this.applyView();
    this.applyBg();
    this.applyCursor();
    this.applyTimerPosition();
    this.renderTimer();
    this.updateEmpty();
    this.startTimerLoop();
    setTimeout(() => this.refreshPdfs(), 50);
  },

  leave() {
    if (!this.entered) return;
    this.entered = false;
    this.stopTimerLoop();
    this.closePopover();
    this.closeTimerSettings();
    this.hideSelectionTools();
    this.cancelLink();
    this.flushSave();
  },

  /* -------- interface fixa -------- */
  buildEmpty() {
    const box = this.els.empty;
    box.innerHTML =
      '<div class="ws-empty-icon">' + svgIcon('board') + '</div>' +
      '<p>Seu quadro está em branco</p>' +
      '<small>Crie cartões de texto, solte PDFs e ligue as ideias com setas. Tudo fica salvo neste navegador.</small>' +
      '<div class="ws-empty-actions">' +
        '<button class="ws-empty-btn primary" data-empty="card">' + svgIcon('plus') + '<span>Novo cartão</span></button>' +
        '<button class="ws-empty-btn" data-empty="pdf">' + svgIcon('file') + '<span>Adicionar PDF</span></button>' +
        '<button class="ws-empty-btn" data-empty="bg">' + svgIcon('image') + '<span>Escolher fundo</span></button>' +
      '</div>';
    box.addEventListener('click', (e) => {
      const b = e.target.closest('[data-empty]');
      if (!b) return;
      const act = b.dataset.empty;
      if (act === 'card') this.addNote();
      else if (act === 'pdf') this.els.filePdf.click();
      else this.openBgPopover();
    });
  },

  buildTopbar() {
    const bar = this.els.topbar;
    bar.innerHTML =
      '<div class="ws-brand">' +
        '<span class="ws-brand-icon">' + svgIcon('board') + '</span>' +
        '<div><b>Área de Trabalho</b><small>quadro infinito</small></div>' +
      '</div>' +
      '<div class="ws-actions" role="toolbar" aria-label="Ferramentas do quadro">' +
        '<button class="ws-tool wide" data-act="card" title="Novo cartão de texto">' + svgIcon('plus') + '<span>Cartão</span></button>' +
        '<button class="ws-tool wide" data-act="pdf" title="Adicionar PDF">' + svgIcon('file') + '<span>PDF</span></button>' +
        '<button class="ws-tool wide" data-act="link" title="Ligar dois cartões">' + svgIcon('arrow') + '<span>Ligar</span></button>' +
        '<span class="ws-tool-sep"></span>' +
        '<button class="ws-tool" data-act="bg" title="Fundo do quadro">' + svgIcon('image') + '</button>' +
        '<button class="ws-tool" data-act="cursor" title="Estilo do cursor">' + svgIcon('cursor') + '</button>' +
        '<button class="ws-tool" data-act="timer" title="Mostrar ou ocultar o cronômetro">' + svgIcon('timer') + '</button>' +
        '<button class="ws-tool" data-act="fit" title="Ajustar o quadro à tela">' + svgIcon('fit') + '</button>' +
      '</div>';
    bar.addEventListener('click', (e) => {
      const b = e.target.closest('[data-act]');
      if (!b) return;
      const act = b.dataset.act;
      if (act === 'card') this.addNote();
      else if (act === 'pdf') this.els.filePdf.click();
      else if (act === 'link') this.beginLink();
      else if (act === 'bg') this.openBgPopover();
      else if (act === 'cursor') this.openCursorPopover();
      else if (act === 'timer') this.toggleTimerVisible();
      else if (act === 'fit') this.fitView();
    });
    this.updateTopbar();
  },

  updateTopbar() {
    const link = this.els.topbar.querySelector('[data-act="link"]');
    if (link) link.classList.toggle('active', !!this.linkFrom);
    const timer = this.els.topbar.querySelector('[data-act="timer"]');
    if (timer && this.board) timer.classList.toggle('active', !!this.board.timer.visible);
  },

  buildZoom() {
    const z = this.els.zoom;
    z.innerHTML =
      '<button class="ws-zoom-btn" data-z="in" title="Aproximar">+</button>' +
      '<div class="ws-zoom-level">100%</div>' +
      '<button class="ws-zoom-btn" data-z="out" title="Afastar">−</button>' +
      '<button class="ws-zoom-btn" data-z="fit" title="Ajustar à tela">' + svgIcon('fit') + '</button>';
    z.addEventListener('click', (e) => {
      const b = e.target.closest('[data-z]');
      if (!b) return;
      if (b.dataset.z === 'in') this.zoomAt(null, null, 1.2);
      else if (b.dataset.z === 'out') this.zoomAt(null, null, 1 / 1.2);
      else this.fitView();
    });
  },

  /* -------- visão: pan, zoom, ajuste -------- */
  applyView() {
    const v = this.board.view;
    this.els.world.style.transform = 'translate(' + v.x.toFixed(2) + 'px,' + v.y.toFixed(2) + 'px) scale(' + v.scale.toFixed(3) + ')';
    const lvl = this.els.zoom.querySelector('.ws-zoom-level');
    if (lvl) lvl.textContent = Math.round(v.scale * 100) + '%';
    this.els.world.style.setProperty('--ws-scale', v.scale);
  },

  screenToWorld(clientX, clientY) {
    const r = this.els.viewport.getBoundingClientRect();
    const v = this.board.view;
    return { x: (clientX - r.left - v.x) / v.scale, y: (clientY - r.top - v.y) / v.scale };
  },

  centerWorld() {
    const r = this.els.viewport.getBoundingClientRect();
    return this.screenToWorld(r.left + r.width / 2, r.top + r.height / 2);
  },

  zoomAt(clientX, clientY, factor) {
    const v = this.board.view;
    const r = this.els.viewport.getBoundingClientRect();
    const px = clientX == null ? r.width / 2 : clientX - r.left;
    const py = clientY == null ? r.height / 2 : clientY - r.top;
    const ns = clamp(v.scale * factor, 0.2, 2.6);
    if (ns === v.scale) return;
    v.x = px - (px - v.x) * (ns / v.scale);
    v.y = py - (py - v.y) * (ns / v.scale);
    v.scale = ns;
    this.applyView();
    this.scheduleSave();
    this.schedulePdfRefresh();
  },

  fitView() {
    const cards = this.board.cards;
    const r = this.els.viewport.getBoundingClientRect();
    if (!cards.length) {
      this.board.view = { x: r.width / 2, y: r.height / 2, scale: 1 };
      this.applyView();
      this.scheduleSave();
      return;
    }
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    cards.forEach(c => {
      minX = Math.min(minX, c.x);
      minY = Math.min(minY, c.y);
      maxX = Math.max(maxX, c.x + c.w);
      maxY = Math.max(maxY, c.y + c.h);
    });
    const pad = 74;
    const bw = Math.max(1, maxX - minX);
    const bh = Math.max(1, maxY - minY);
    const scale = clamp(Math.min((r.width - pad * 2) / bw, (r.height - pad * 2 - 30) / bh), 0.2, 1.6);
    this.board.view = {
      scale,
      x: r.width / 2 - (minX + bw / 2) * scale,
      y: r.height / 2 - (minY + bh / 2) * scale
    };
    this.applyView();
    this.scheduleSave();
    this.schedulePdfRefresh();
  },

  updateEmpty() {
    if (!this.els.empty || !this.board) return;
    this.els.empty.hidden = this.board.cards.length > 0;
  },

  /* -------- fundo e cursor -------- */
  applyBg() {
    const vp = this.els.viewport;
    const bg = this.board.bg;
    if (bg.image && this.bgUrl) {
      vp.style.backgroundImage = 'url("' + this.bgUrl + '")';
      vp.style.backgroundSize = 'cover';
      vp.style.backgroundPosition = 'center';
      vp.style.backgroundColor = bg.color || 'var(--bg)';
    } else {
      vp.style.backgroundImage = 'none';
      vp.style.backgroundColor = bg.color || 'var(--bg)';
    }
  },

  applyCursor() {
    this.els.viewport.style.cursor = wsCursorCss(this.board.cursor);
  },

  setBgColor(color, keepOpen) {
    color = wsColor(color, '');
    if (this.board.bg.image) {
      this.board.bg.image = false;
      this.bgUrl = null;
      WorkspaceDB.delFile('bg').catch(() => {});
    }
    this.board.bg.color = color;
    this.applyBg();
    this.scheduleSave();
    if (keepOpen) this.openBgPopover();
  },

  refreshBgPopover() {
    if (this.popover === 'bg') {
      this.popover = null;
      this.openBgPopover();
    }
  },

  async setBgImageFile(file) {
    if (!file || !/^image\//.test(file.type)) return;
    if (file.size > 10 * 1024 * 1024) {
      toast('Imagem muito grande — use até 10 MB', 'image');
      return;
    }
    try {
      const url = await readFileAsDataURL(file);
      await WorkspaceDB.putFile('bg', url);
      this.bgUrl = url;
      this.board.bg.image = true;
      this.applyBg();
      this.scheduleSave();
      this.refreshBgPopover();
      toast('Fundo atualizado', 'image');
    } catch (e) {
      toast('Não foi possível salvar a imagem', 'close');
    }
  },

  removeBgImage() {
    this.bgUrl = null;
    this.board.bg.image = false;
    WorkspaceDB.delFile('bg').catch(() => {});
    this.applyBg();
    this.scheduleSave();
    this.refreshBgPopover();
  },

  /* -------- popovers -------- */
  closePopover() {
    this.popover = null;
    this.els.popovers.innerHTML = '';
  },

  openBgPopover() {
    if (this.popover === 'bg') { this.closePopover(); return; }
    this.closeTimerSettings();
    this.popover = 'bg';
    const bg = this.board.bg;
    const current = bg.color || '';
    let html = '<div class="ws-popover"><p class="ws-pop-title">Fundo do quadro</p><div class="ws-color-grid">';
    WS_BG_SWATCHES.forEach(c => {
      const val = c || '';
      const bgc = c || 'var(--bg)';
      html += '<button class="ws-swatch' + (val === current && !bg.image ? ' active' : '') + '" data-bgcolor="' + val + '" title="' + (val || 'Cor do tema') + '" style="background:' + bgc + '"></button>';
    });
    html += '</div>' +
      '<label class="ws-color-custom"><input type="color" value="' + (wsColor(current, '#0b0f1a') || '#0b0f1a') + '" data-bgcustom><span>Cor personalizada</span></label>' +
      '<div class="ws-pop-sub">Imagem</div>' +
      '<div class="ws-pop-row">' +
        '<button class="ws-pop-chip" data-bgimg>' + svgIcon('upload') + ' Escolher imagem</button>' +
        (bg.image ? '<button class="ws-pop-chip" data-bgdel>Remover</button>' : '') +
      '</div>' +
      '<p class="ws-pop-note">Cor ou imagem de até 10 MB. O fundo fica salvo junto com o quadro.</p></div>';
    this.els.popovers.innerHTML = html;
    const pop = this.els.popovers.firstChild;
    pop.addEventListener('click', (e) => {
      const colorBtn = e.target.closest('[data-bgcolor]');
      if (colorBtn) { this.setBgColor(colorBtn.dataset.bgcolor); this.refreshBgPopover(); return; }
      if (e.target.closest('[data-bgimg]')) { this.els.fileBg.click(); return; }
      if (e.target.closest('[data-bgdel]')) { this.removeBgImage(); return; }
    });
    const custom = pop.querySelector('[data-bgcustom]');
    if (custom) custom.addEventListener('change', () => { this.setBgColor(custom.value); this.refreshBgPopover(); });
  },

  openCursorPopover() {
    if (this.popover === 'cursor') { this.closePopover(); return; }
    this.closeTimerSettings();
    this.popover = 'cursor';
    let html = '<div class="ws-popover"><p class="ws-pop-title">Cursor do quadro</p>';
    WS_CURSOR_GROUPS.forEach(g => {
      html += '<div class="ws-pop-sub">' + g.label + '</div><div class="ws-cursor-row">';
      WS_CURSORS.filter(c => c.group === g.id).forEach(c => {
        const prev = c.kind === 'native'
          ? '<span class="ws-cur-word">' + c.short + '</span>'
          : '<span class="ws-cur-prev">' + wsCursorSvg(c) + '</span><em>' + c.short + '</em>';
        html += '<button class="ws-cur-btn' + (c.kind === 'native' ? ' native' : '') +
          (this.board.cursor === c.id ? ' active' : '') + '" data-cursor="' + c.id +
          '" title="' + c.label + '" style="cursor:' + wsCursorCss(c.id).replace(/"/g, '&quot;') + '">' + prev + '</button>';
      });
      html += '</div>';
    });
    html += '<p class="ws-pop-note">Vale para o fundo do quadro. Cartões e textos mantêm o cursor próprio.</p></div>';
    this.els.popovers.innerHTML = html;
    this.els.popovers.firstChild.addEventListener('click', (e) => {
      const b = e.target.closest('[data-cursor]');
      if (!b) return;
      this.board.cursor = b.dataset.cursor;
      this.applyCursor();
      this.scheduleSave();
      this.els.popovers.querySelectorAll('[data-cursor]').forEach(n => {
        n.classList.toggle('active', n.dataset.cursor === this.board.cursor);
      });
    });
  },

  openCustomPopover(html) {
    this.closeTimerSettings();
    this.popover = 'custom';
    this.els.popovers.innerHTML = '<div class="ws-popover">' + html + '</div>';
    return this.els.popovers.firstChild;
  },

  /* -------- cartões -------- */
  renderAll() {
    this.els.world.querySelectorAll('.ws-card').forEach(n => n.remove());
    this.cardEls.clear();
    this.board.cards.forEach(card => this.createCardEl(card));
    this.renderArrows();
    this.updateEmpty();
  },

  cardButton(icon, title, cls) {
    const b = el('button', 'ws-card-btn' + (cls ? ' ' + cls : ''));
    b.type = 'button';
    b.title = title;
    b.setAttribute('aria-label', title);
    b.innerHTML = svgIcon(icon);
    return b;
  },

  createCardEl(card) {
    const node = el('article', 'ws-card ws-' + card.type);
    node.dataset.id = card.id;
    node.style.transform = 'translate(' + card.x + 'px,' + card.y + 'px)';
    node.style.width = card.w + 'px';
    node.style.height = card.h + 'px';

    const head = el('header', 'ws-card-head');
    const grip = el('span', 'ws-card-grip', svgIcon('grip'));
    head.append(grip);

    if (card.type === 'note') {
      const title = el('span', 'ws-card-title', 'Nota');
      head.append(title);
      if (card.source) {
        const src = el('button', 'ws-card-src');
        src.type = 'button';
        src.title = 'Abrir o PDF de origem';
        src.innerHTML = svgIcon('file') + '<span>p.' + card.source.page + '</span>';
        src.addEventListener('click', (e) => {
          e.stopPropagation();
          this.revealSource(card);
        });
        head.append(src);
      }
      const link = this.cardButton('arrow', 'Ligar a outro cartão');
      link.addEventListener('click', (e) => {
        e.stopPropagation();
        this.beginLink(card.id);
      });
      const del = this.cardButton('close', 'Remover cartão', 'danger');
      del.addEventListener('click', (e) => {
        e.stopPropagation();
        this.removeCard(card);
      });
      head.append(link, del);

      const body = el('textarea', 'ws-note-body');
      body.placeholder = 'Escreva algo…';
      body.value = card.text || '';
      body.spellcheck = false;
      body.addEventListener('input', () => {
        card.text = body.value;
        this.scheduleSave();
      });

      const resize = el('div', 'ws-resize');
      resize.title = 'Redimensionar';
      node.append(head, body, resize);
      resize.addEventListener('pointerdown', (e) => this.startResize(e, card));
    } else {
      const meta = this.pdfMeta(card);
      const title = el('span', 'ws-card-title');
      title.textContent = meta ? meta.name : 'PDF';
      title.title = meta ? meta.name : 'PDF';
      head.append(title);

      const page = el('span', 'ws-pdf-page');
      page.textContent = '1 / ' + (meta && meta.pages ? meta.pages : '…');
      page.title = 'Clique no PDF para avançar de página';
      head.append(page);

      const link = this.cardButton('arrow', 'Ligar a outro cartão');
      link.addEventListener('click', (e) => {
        e.stopPropagation();
        this.beginLink(card.id);
      });
      const hl = this.cardButton('highlight', 'Destaques desta página');
      hl.addEventListener('click', (e) => {
        e.stopPropagation();
        this.openHighlights(card);
      });
      const del = this.cardButton('close', 'Remover PDF', 'danger');
      del.addEventListener('click', (e) => {
        e.stopPropagation();
        this.removeCard(card);
      });
      head.append(link, hl, del);

      const body = el('div', 'ws-pdf-body');
      body.innerHTML =
        '<canvas></canvas>' +
        '<div class="ws-hl-layer"></div>' +
        '<div class="ws-text-layer"></div>' +
        '<div class="ws-pdf-loading">carregando PDF</div>';
      const resize = el('div', 'ws-resize');
      resize.title = 'Redimensionar';
      node.append(head, body, resize);
      resize.addEventListener('pointerdown', (e) => this.startResize(e, card));
      body.addEventListener('pointerdown', (e) => this.onPdfPointerDown(e, card, body));
    }

    head.addEventListener('pointerdown', (e) => {
      if (e.target.closest('button')) return;
      this.startCardDrag(e, card);
    });

    node.addEventListener('pointerdown', () => this.select(card.id));
    this.els.world.append(node);
    this.cardEls.set(card.id, node);
    return node;
  },

  rebuildCard(card) {
    const old = this.cardEls.get(card.id);
    if (old) old.remove();
    this.cardEls.delete(card.id);
    this.pdfRendered.delete(card.id);
    this.createCardEl(card);
  },

  pdfMeta(card) {
    return this.board.pdfs.find(p => p.id === card.pdfId) || null;
  },

  addNote(opts) {
    opts = opts || {};
    const c = this.centerWorld();
    const card = {
      id: uid(),
      type: 'note',
      x: opts.x == null ? c.x - 140 : opts.x,
      y: opts.y == null ? c.y - 85 : opts.y,
      w: opts.w || 280,
      h: opts.h || 170,
      text: opts.text || '',
      source: opts.source || null
    };
    this.board.cards.push(card);
    this.createCardEl(card);
    this.updateEmpty();
    this.scheduleSave();
    this.select(card.id);
    if (!opts.text && opts.focus !== false) {
      const node = this.cardEls.get(card.id);
      const ta = node && node.querySelector('.ws-note-body');
      if (ta) setTimeout(() => ta.focus(), 30);
    }
    return card;
  },

  removeCard(card) {
    if (!card) return;
    if (card.type === 'pdf' && !confirm('Remover este PDF do quadro?\nO arquivo salvo também será apagado.')) return;

    this.board.arrows = this.board.arrows.filter(a => a.from !== card.id && a.to !== card.id);
    this.board.cards = this.board.cards.filter(c => c.id !== card.id);
    const node = this.cardEls.get(card.id);
    if (node) node.remove();
    this.cardEls.delete(card.id);
    this.pdfRendered.delete(card.id);
    this.pdfPageDims.delete(card.id);
    this.pdfTokens.set(card.id, 'revoked');

    if (card.type === 'pdf') {
      const doc = this.pdfDocs.get(card.pdfId);
      if (doc && doc.destroy) { try { doc.destroy(); } catch (e) { /* ignora */ } }
      this.pdfDocs.delete(card.pdfId);
      this.pdfPromises.delete(card.pdfId);
      WorkspaceDB.delFile(card.pdfId).catch(() => {});
      this.board.pdfs = this.board.pdfs.filter(p => p.id !== card.pdfId);
      this.board.cards.forEach(c => {
        if (c.type === 'note' && c.source && c.source.pdfId === card.pdfId) {
          c.source = null;
          this.rebuildCard(c);
        }
      });
    }

    if (this.selCard === card.id) this.selCard = null;
    this.renderArrows();
    this.updateEmpty();
    this.scheduleSave();
  },

  select(id) {
    if (this.linkFrom && id && id !== this.linkFrom) {
      this.makeArrow(this.linkFrom, id);
      this.cancelLink();
      return;
    }
    this.selCard = id || null;
    this.selArrow = null;
    this.cardEls.forEach((node, cid) => node.classList.toggle('selected', cid === id));
    this.updateArrowSelection();
  },

  selectArrow(id) {
    this.selCard = null;
    this.cardEls.forEach(n => n.classList.remove('selected'));
    this.selArrow = id;
    this.updateArrowSelection();
  },

  updateArrowSelection() {
    this.arrowEls.forEach((o, id) => {
      o.line.classList.toggle('sel', id === this.selArrow);
      o.hit.classList.toggle('sel', id === this.selArrow);
    });
  },

  beginLink(cardId) {
    const from = cardId || this.selCard;
    if (!from) { toast('Selecione um cartão para começar a ligação', 'arrow'); return; }
    if (this.linkFrom === from) { this.cancelLink(); return; }
    this.cancelLink();
    this.linkFrom = from;
    const node = this.cardEls.get(from);
    if (node) node.classList.add('link-source');
    this.updateTopbar();
    toast('Clique no cartão de destino · Esc cancela', 'arrow');
  },

  cancelLink() {
    if (!this.linkFrom) return;
    const node = this.cardEls.get(this.linkFrom);
    if (node) node.classList.remove('link-source');
    this.linkFrom = null;
    this.updateTopbar();
  },

  /* -------- setas -------- */
  makeArrow(from, to) {
    if (!from || !to || from === to) return;
    if (this.board.arrows.some(a => a.from === from && a.to === to)) {
      toast('Esses cartões já estão ligados', 'arrow');
      return;
    }
    const a = { id: uid(), from, to };
    this.board.arrows.push(a);
    this.createArrowEl(a);
    this.updateArrow(a.id);
    this.scheduleSave();
  },

  removeArrow(id) {
    this.board.arrows = this.board.arrows.filter(a => a.id !== id);
    const o = this.arrowEls.get(id);
    if (o) o.g.remove();
    this.arrowEls.delete(id);
    if (this.selArrow === id) this.selArrow = null;
    this.scheduleSave();
  },

  renderArrows() {
    this.els.arrowLayer.innerHTML = '';
    this.arrowEls.clear();
    this.board.arrows.forEach(a => this.createArrowEl(a));
    this.board.arrows.forEach(a => this.updateArrow(a.id));
  },

  createArrowEl(a) {
    const NS = 'http://www.w3.org/2000/svg';
    const g = document.createElementNS(NS, 'g');
    g.dataset.id = a.id;
    const hit = document.createElementNS(NS, 'path');
    hit.setAttribute('class', 'ws-arrow-hit');
    const line = document.createElementNS(NS, 'path');
    line.setAttribute('class', 'ws-arrow');
    line.setAttribute('marker-end', 'url(#ws-arrowhead)');
    const title = document.createElementNS(NS, 'title');
    title.textContent = 'Ligação — Delete remove';
    g.append(hit, line, title);
    hit.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      this.selectArrow(a.id);
    });
    hit.addEventListener('dblclick', (e) => {
      e.stopPropagation();
      this.removeArrow(a.id);
    });
    this.els.arrowLayer.append(g);
    this.arrowEls.set(a.id, { g, hit, line, arrow: a });
  },

  updateArrow(id) {
    const o = this.arrowEls.get(id);
    if (!o) return;
    const a = o.arrow;
    const from = this.board.cards.find(c => c.id === a.from);
    const to = this.board.cards.find(c => c.id === a.to);
    if (!from || !to) { o.g.style.display = 'none'; return; }
    o.g.style.display = '';
    const fc = { x: from.x + from.w / 2, y: from.y + from.h / 2 };
    const tc = { x: to.x + to.w / 2, y: to.y + to.h / 2 };
    const p1 = this.cardEdge(from, tc.x, tc.y);
    const p2 = this.cardEdge(to, fc.x, fc.y);
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    let d;
    if (Math.abs(dx) >= Math.abs(dy)) {
      const mx = p1.x + dx / 2;
      d = 'M ' + p1.x.toFixed(1) + ' ' + p1.y.toFixed(1) +
        ' C ' + mx.toFixed(1) + ' ' + p1.y.toFixed(1) + ', ' + mx.toFixed(1) + ' ' + p2.y.toFixed(1) +
        ', ' + p2.x.toFixed(1) + ' ' + p2.y.toFixed(1);
    } else {
      const my = p1.y + dy / 2;
      d = 'M ' + p1.x.toFixed(1) + ' ' + p1.y.toFixed(1) +
        ' C ' + p1.x.toFixed(1) + ' ' + my.toFixed(1) + ', ' + p2.x.toFixed(1) + ' ' + my.toFixed(1) +
        ', ' + p2.x.toFixed(1) + ' ' + p2.y.toFixed(1);
    }
    o.hit.setAttribute('d', d);
    o.line.setAttribute('d', d);
  },

  cardEdge(card, tx, ty) {
    const cx = card.x + card.w / 2;
    const cy = card.y + card.h / 2;
    const dx = tx - cx;
    const dy = ty - cy;
    if (!dx && !dy) return { x: cx, y: cy };
    const sx = dx ? (card.w / 2 + 2) / Math.abs(dx) : Infinity;
    const sy = dy ? (card.h / 2 + 2) / Math.abs(dy) : Infinity;
    const t = Math.min(sx, sy);
    return { x: cx + dx * t, y: cy + dy * t };
  },

  updateArrowsFor(cardId) {
    this.board.arrows.forEach(a => {
      if (a.from === cardId || a.to === cardId) this.updateArrow(a.id);
    });
  },

  /* -------- PDFs -------- */
  loadPdfLib() {
    if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
    if (this.pdfLibPromise) return this.pdfLibPromise;
    this.pdfLibPromise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'js/vendor/pdf.min.js';
      s.onload = () => {
        try { window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'js/vendor/pdf.worker.min.js'; }
        catch (e) { /* ignora */ }
        resolve(window.pdfjsLib);
      };
      s.onerror = () => reject(new Error('pdf.js não carregou'));
      document.head.append(s);
    });
    return this.pdfLibPromise;
  },

  ensurePdfDoc(pdfId) {
    if (this.pdfDocs.has(pdfId)) return Promise.resolve(this.pdfDocs.get(pdfId));
    if (this.pdfPromises.has(pdfId)) return this.pdfPromises.get(pdfId);
    const job = (async () => {
      await this.loadPdfLib();
      const buf = await WorkspaceDB.getFile(pdfId);
      if (!buf) throw new Error('arquivo ausente');
      const doc = await window.pdfjsLib.getDocument({
        data: new Uint8Array(buf.slice(0)),
        isEvalSupported: false
      }).promise;
      const meta = this.board.pdfs.find(p => p.id === pdfId);
      if (meta) {
        meta.pages = doc.numPages;
        this.scheduleSave();
      }
      this.pdfDocs.set(pdfId, doc);
      this.pdfPromises.delete(pdfId);
      return doc;
    })();
    this.pdfPromises.set(pdfId, job);
    job.catch(() => { this.pdfPromises.delete(pdfId); });
    return job;
  },

  refreshPdfs() {
    if (!this.entered) return;
    this.board.cards.forEach(card => {
      if (card.type === 'pdf') this.renderPdfCard(card);
    });
  },

  schedulePdfRefresh() {
    clearTimeout(this.pdfRefreshTimer);
    this.pdfRefreshTimer = setTimeout(() => this.refreshPdfs(), 420);
  },

  async renderPdfCard(card, force) {
    if (!this.entered) return;
    const node = this.cardEls.get(card.id);
    if (!node) return;
    const body = node.querySelector('.ws-pdf-body');
    if (!body) return;
    const bw = Math.floor(body.clientWidth);
    const bh = Math.floor(body.clientHeight);
    if (bw < 24 || bh < 24) return;

    const quality = clamp((window.devicePixelRatio || 1) * this.board.view.scale, 1, 2.4);
    const key = [card.pdfId, card.page, bw, bh, Math.round(quality * 10)].join('|');
    const canvas = body.querySelector('canvas');
    const textLayer = body.querySelector('.ws-text-layer');
    const loading = body.querySelector('.ws-pdf-loading');
    if (!force && this.pdfRendered.get(card.id) === key && canvas.width > 0) return;

    const token = uid();
    this.pdfTokens.set(card.id, token);
    loading.hidden = false;
    loading.textContent = 'carregando PDF';

    try {
      const doc = await this.ensurePdfDoc(card.pdfId);
      if (this.pdfTokens.get(card.id) !== token) return;
      const num = doc.numPages || 1;
      card.page = clamp(card.page || 1, 1, num);
      const page = await doc.getPage(card.page);
      if (this.pdfTokens.get(card.id) !== token) return;

      const base = page.getViewport({ scale: 1 });
      const fit = Math.min(bw / base.width, bh / base.height);
      const dispW = base.width * fit;
      const dispH = base.height * fit;

      const prev = this.pdfTasks.get(card.id);
      if (prev && prev.cancel) { try { prev.cancel(); } catch (e) { /* ignora */ } }

      const renderVp = page.getViewport({ scale: fit * quality });
      canvas.width = Math.max(1, Math.floor(renderVp.width));
      canvas.height = Math.max(1, Math.floor(renderVp.height));
      canvas.style.width = dispW + 'px';
      canvas.style.height = dispH + 'px';
      const ctx = canvas.getContext('2d', { alpha: false });
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      const task = page.render({ canvasContext: ctx, viewport: renderVp });
      this.pdfTasks.set(card.id, task);
      await task.promise;
      if (this.pdfTokens.get(card.id) !== token) return;
      this.pdfTasks.delete(card.id);

      textLayer.innerHTML = '';
      textLayer.style.width = dispW + 'px';
      textLayer.style.height = dispH + 'px';
      textLayer.style.setProperty('--scale-factor', String(fit));
      const content = await page.getTextContent();
      if (this.pdfTokens.get(card.id) !== token) return;
      const textTask = window.pdfjsLib.renderTextLayer({
        textContentSource: content,
        container: textLayer,
        viewport: page.getViewport({ scale: fit }),
        textDivs: []
      });
      await textTask.promise;
      if (this.pdfTokens.get(card.id) !== token) return;

      this.pdfPageDims.set(card.id, { w: dispW, h: dispH });
      const pageEl = node.querySelector('.ws-pdf-page');
      if (pageEl) pageEl.textContent = card.page + ' / ' + num;
      this.pdfRendered.set(card.id, key);
      this.renderHighlights(card);
      loading.hidden = true;
      this.scheduleSave();
    } catch (err) {
      if (this.pdfTokens.get(card.id) === token) {
        loading.hidden = false;
        loading.textContent = 'Não foi possível abrir este PDF';
      }
    }
  },

  nextPdfPage(card) {
    const meta = this.pdfMeta(card);
    const total = meta && meta.pages ? meta.pages : 0;
    card.page = total ? (card.page >= total ? 1 : card.page + 1) : (card.page || 1) + 1;
    this.pdfRendered.delete(card.id);
    this.scheduleSave();
    this.renderPdfCard(card, true);
  },

  async addPdfFile(file, at) {
    if (!file) return;
    const isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name || '');
    if (!isPdf) return;
    if (this.board.pdfs.length >= 5) {
      toast('Limite de 5 PDFs no quadro', 'file');
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      if (!confirm('Este PDF tem ' + (file.size / 1048576).toFixed(1) + ' MB e pode deixar o quadro lento. Adicionar mesmo assim?')) return;
    }
    let buf;
    try { buf = await file.arrayBuffer(); }
    catch (e) { toast('Não foi possível ler o PDF', 'close'); return; }

    const id = uid();
    try { await WorkspaceDB.putFile(id, buf); }
    catch (e) { toast('Sem espaço para salvar este PDF', 'close'); return; }

    const name = (file.name || 'Documento.pdf').replace(/\.pdf$/i, '');
    this.board.pdfs.push({ id, name, size: file.size, pages: 0, highlights: [] });

    const p = at || this.centerWorld();
    const card = {
      id: uid(),
      type: 'pdf',
      pdfId: id,
      x: p.x - 180,
      y: p.y - 230,
      w: 360,
      h: 460,
      page: 1
    };
    this.board.cards.push(card);
    this.createCardEl(card);
    this.updateEmpty();
    this.scheduleSave();
    this.select(card.id);
    this.renderPdfCard(card, true);
    toast('PDF adicionado ao quadro', 'file');
  },

  revealSource(noteCard) {
    if (!noteCard.source) return;
    const pdf = this.board.cards.find(c => c.type === 'pdf' && c.pdfId === noteCard.source.pdfId);
    if (!pdf) { toast('O PDF de origem não está mais no quadro', 'file'); return; }
    pdf.page = Math.max(1, noteCard.source.page || 1);
    this.pdfRendered.delete(pdf.id);
    this.renderPdfCard(pdf, true);
    const r = this.els.viewport.getBoundingClientRect();
    const v = this.board.view;
    v.x = r.width / 2 - (pdf.x + pdf.w / 2) * v.scale;
    v.y = r.height / 2 - (pdf.y + pdf.h / 2) * v.scale;
    this.applyView();
    this.scheduleSave();
    this.select(pdf.id);
  },

  /* -------- destaques -------- */
  renderHighlights(card) {
    const node = this.cardEls.get(card.id);
    if (!node) return;
    const layer = node.querySelector('.ws-hl-layer');
    const meta = this.pdfMeta(card);
    const dims = this.pdfPageDims.get(card.id);
    if (!layer || !meta || !dims) return;
    layer.style.width = dims.w + 'px';
    layer.style.height = dims.h + 'px';
    layer.innerHTML = '';
    (meta.highlights || []).forEach(h => {
      if (h.page !== card.page) return;
      h.rects.forEach(r => {
        const mark = el('i', 'ws-hl');
        mark.style.left = (r.x * 100).toFixed(3) + '%';
        mark.style.top = (r.y * 100).toFixed(3) + '%';
        mark.style.width = (r.w * 100).toFixed(3) + '%';
        mark.style.height = (r.h * 100).toFixed(3) + '%';
        mark.style.background = h.color;
        layer.append(mark);
      });
    });
  },

  openHighlights(card) {
    const meta = this.pdfMeta(card);
    if (!meta) return;
    const list = (meta.highlights || []).filter(h => h.page === card.page);
    if (!list.length) {
      toast('Nenhum destaque nesta página', 'highlight');
      return;
    }
    let html = '<p class="ws-pop-title">Destaques · p. ' + card.page + '</p><div class="ws-hl-list">';
    list.forEach(h => {
      html += '<div class="ws-hl-item">' +
        '<i style="background:' + h.color + '"></i>' +
        '<span title="' + wsEscape(h.text) + '">' + wsEscape((h.text || 'trecho').slice(0, 72)) + '</span>' +
        '<button data-hldel="' + h.id + '" title="Remover destaque">' + svgIcon('trash') + '</button></div>';
    });
    html += '</div><p class="ws-pop-note">Os destaques ficam salvos com o PDF.</p>';
    const pop = this.openCustomPopover(html);
    pop.addEventListener('click', (e) => {
      const b = e.target.closest('[data-hldel]');
      if (!b) return;
      meta.highlights = (meta.highlights || []).filter(h => h.id !== b.dataset.hldel);
      this.renderHighlights(card);
      this.scheduleSave();
      this.openHighlights(card);
    });
  },

  /* -------- eventos gerais -------- */
  bindEvents() {
    const vp = this.els.viewport;

    vp.addEventListener('pointerdown', (e) => this.onViewportPointerDown(e));
    vp.addEventListener('wheel', (e) => {
      if (!this.entered) return;
      e.preventDefault();
      const factor = Math.exp(-e.deltaY * 0.0016);
      this.zoomAt(e.clientX, e.clientY, factor);
    }, { passive: false });

    vp.addEventListener('dblclick', (e) => {
      if (e.target.closest('.ws-card, .ws-topbar, .ws-zoom, .ws-timer, .ws-popover, .ws-sel-tools, .ws-empty')) return;
      const p = this.screenToWorld(e.clientX, e.clientY);
      this.addNote({ x: p.x - 140, y: p.y - 85, focus: true });
    });

    document.addEventListener('pointermove', (e) => this.onPointerMove(e));
    document.addEventListener('pointerup', (e) => this.onPointerUp(e));
    document.addEventListener('pointercancel', (e) => this.onPointerUp(e));
    document.addEventListener('pointerdown', (e) => this.onDocPointerDown(e));
    document.addEventListener('keydown', (e) => this.onKeyDown(e));

    window.addEventListener('resize', () => {
      if (!this.board) return;
      this.applyTimerPosition();
      if (!this.els.timerSettings.hidden) this.positionTimerSettings();
    });

    this.els.selTools.addEventListener('pointerdown', (e) => e.stopPropagation());
    this.els.selTools.addEventListener('click', (e) => {
      const dot = e.target.closest('[data-hlcolor]');
      if (dot) { this.applyHighlight(dot.dataset.hlcolor); return; }
      if (e.target.closest('[data-selcard]')) this.selectionToCard();
    });

    this.els.filePdf.addEventListener('change', () => {
      const files = Array.from(this.els.filePdf.files || []);
      this.els.filePdf.value = '';
      const at = this.centerWorld();
      files.forEach((f, i) => this.addPdfFile(f, { x: at.x + i * 26, y: at.y + i * 26 }));
    });

    this.els.fileBg.addEventListener('change', () => {
      const f = (this.els.fileBg.files || [])[0];
      this.els.fileBg.value = '';
      if (f) this.setBgImageFile(f);
    });

    const shell = this.els.shell;
    const hasFiles = (e) => !!(e.dataTransfer && Array.from(e.dataTransfer.types || []).indexOf('Files') >= 0);
    shell.addEventListener('dragenter', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      shell.classList.add('drop-active');
    });
    shell.addEventListener('dragover', (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
      shell.classList.add('drop-active');
    });
    shell.addEventListener('dragleave', (e) => {
      if (e.target === shell || !shell.contains(e.relatedTarget)) shell.classList.remove('drop-active');
    });
    shell.addEventListener('drop', async (e) => {
      if (!hasFiles(e)) return;
      e.preventDefault();
      shell.classList.remove('drop-active');
      const files = Array.from(e.dataTransfer.files || []);
      const at = this.screenToWorld(e.clientX, e.clientY);
      let i = 0;
      for (const f of files) {
        if (f.type === 'application/pdf' || /\.pdf$/i.test(f.name || '')) {
          await this.addPdfFile(f, { x: at.x + i * 26, y: at.y + i * 26 });
          i++;
        } else if (/^image\//.test(f.type)) {
          await this.setBgImageFile(f);
        }
      }
    });
  },

  onViewportPointerDown(e) {
    if (!this.entered) return;
    if (e.button != null && e.button !== 0 && e.button !== 1) return;
    if (e.target.closest('.ws-card, .ws-topbar, .ws-zoom, .ws-timer, .ws-popover, .ws-sel-tools, .ws-empty')) return;

    this.closePopover();
    this.closeTimerSettings();
    this.hideSelectionTools();
    this.select(null);
    this.cancelLink();

    this.panning = {
      id: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      viewX: this.board.view.x,
      viewY: this.board.view.y
    };
    this.els.viewport.classList.add('panning');
    try { this.els.viewport.setPointerCapture(e.pointerId); } catch (err) { /* ignora */ }
    e.preventDefault();
  },

  onPointerMove(e) {
    if (this.panning) {
      const v = this.board.view;
      v.x = this.panning.viewX + (e.clientX - this.panning.startX);
      v.y = this.panning.viewY + (e.clientY - this.panning.startY);
      this.applyView();
      return;
    }

    if (this.cardDrag) {
      const d = this.cardDrag;
      const p = this.screenToWorld(e.clientX, e.clientY);
      d.card.x = d.orig.x + (p.x - d.start.x);
      d.card.y = d.orig.y + (p.y - d.start.y);
      if (Math.hypot(e.clientX - d.screenX, e.clientY - d.screenY) > 3) d.moved = true;
      const node = this.cardEls.get(d.card.id);
      if (node) node.style.transform = 'translate(' + d.card.x + 'px,' + d.card.y + 'px)';
      this.updateArrowsFor(d.card.id);
      return;
    }

    if (this.cardResize) {
      const r = this.cardResize;
      const scale = this.board.view.scale;
      r.card.w = clamp(r.origW + (e.clientX - r.startX) / scale, 190, 2400);
      r.card.h = clamp(r.origH + (e.clientY - r.startY) / scale, 96, 2400);
      const node = this.cardEls.get(r.card.id);
      if (node) {
        node.style.width = r.card.w + 'px';
        node.style.height = r.card.h + 'px';
      }
      this.updateArrowsFor(r.card.id);
      return;
    }

    if (this.timerDrag) {
      const d = this.timerDrag;
      const t = this.board.timer;
      t.x = d.origX + (e.clientX - d.startX);
      t.y = d.origY + (e.clientY - d.startY);
      if (Math.hypot(e.clientX - d.startX, e.clientY - d.startY) > 4) d.moved = true;
      this.applyTimerPosition();
      if (!this.els.timerSettings.hidden) this.positionTimerSettings();
      return;
    }

    if (this.selDrag) {
      const d = this.selDrag;
      if (Math.hypot(e.clientX - d.startX, e.clientY - d.startY) > 7) d.moved = true;
      if (d.moved) this.moveDragGhost(e.clientX, e.clientY, d.text);
      return;
    }

    if (this.pdfPress) {
      if (Math.hypot(e.clientX - this.pdfPress.startX, e.clientY - this.pdfPress.startY) > 6) {
        this.pdfPress.moved = true;
      }
    }
  },

  onPointerUp(e) {
    if (this.panning) {
      this.els.viewport.classList.remove('panning');
      try { this.els.viewport.releasePointerCapture(this.panning.id); } catch (err) { /* ignora */ }
      this.panning = null;
      this.scheduleSave();
      return;
    }

    if (this.cardDrag) {
      const d = this.cardDrag;
      this.cardDrag = null;
      this.scheduleSave();
      if (d.moved) this.scheduleSave();
      return;
    }

    if (this.cardResize) {
      const r = this.cardResize;
      this.cardResize = null;
      this.scheduleSave();
      if (r.card.type === 'pdf') this.renderPdfCard(r.card, true);
      return;
    }

    if (this.timerDrag) {
      const d = this.timerDrag;
      this.timerDrag = null;
      const timer = this.els.timer;
      if (timer) timer.classList.remove('dragging');
      if (d.ball && !d.moved) {
        this.board.timer.min = false;
        this.renderTimer();
      }
      this.scheduleSave();
      return;
    }

    if (this.selDrag) {
      const d = this.selDrag;
      this.selDrag = null;
      this.removeDragGhost();
      if (d.moved) {
        const node = this.cardEls.get(d.card.id);
        const rect = node ? node.getBoundingClientRect() : null;
        const outside = !rect || e.clientX < rect.left - 2 || e.clientX > rect.right + 2 ||
          e.clientY < rect.top - 2 || e.clientY > rect.bottom + 2;
        if (outside) {
          this.createLinkedCardFromSelection(d.card, d.text, e.clientX, e.clientY);
          this.clearNativeSelection();
          this.hideSelectionTools();
          return;
        }
      }
      setTimeout(() => this.showSelectionTools(), 0);
      return;
    }

    if (this.pdfPress) {
      const press = this.pdfPress;
      this.pdfPress = null;
      if (!press.moved) this.nextPdfPage(press.card);
      setTimeout(() => this.showSelectionTools(), 0);
    }
  },

  onDocPointerDown(e) {
    if (!this.entered) return;
    const t = e.target;
    if (this.popover && !t.closest('.ws-popover') && !t.closest('[data-act="bg"]') && !t.closest('[data-act="cursor"]')) {
      this.closePopover();
    }
    if (!this.els.timerSettings.hidden && !t.closest('.ws-timer-settings') && !t.closest('#ws-timer') && !t.closest('[data-tset]')) {
      this.closeTimerSettings();
    }
    if (this.selection && !t.closest('#ws-sel-tools') && !t.closest('.ws-text-layer')) {
      this.hideSelectionTools();
    }
  },

  onKeyDown(e) {
    if (!this.entered) return;
    const tag = (e.target.tagName || '').toUpperCase();
    const editing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || e.target.isContentEditable;

    if (e.key === 'Escape') {
      this.cancelLink();
      this.select(null);
      this.hideSelectionTools();
      this.closePopover();
      this.closeTimerSettings();
      return;
    }
    if (editing) return;
    if (e.key === 'Delete' || e.key === 'Backspace') {
      if (this.selArrow) {
        e.preventDefault();
        this.removeArrow(this.selArrow);
        this.selArrow = null;
      } else if (this.selCard) {
        e.preventDefault();
        const card = this.board.cards.find(c => c.id === this.selCard);
        if (card) this.removeCard(card);
      }
    }
  },

  startCardDrag(e, card) {
    if (e.button != null && e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    this.select(card.id);
    const start = this.screenToWorld(e.clientX, e.clientY);
    this.cardDrag = {
      card,
      start,
      orig: { x: card.x, y: card.y },
      screenX: e.clientX,
      screenY: e.clientY,
      moved: false,
      id: e.pointerId
    };
  },

  startResize(e, card) {
    if (e.button != null && e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    this.select(card.id);
    this.cardResize = {
      card,
      startX: e.clientX,
      startY: e.clientY,
      origW: card.w,
      origH: card.h,
      id: e.pointerId
    };
  },

  /* -------- seleção de texto no PDF -------- */
  onPdfPointerDown(e, card, body) {
    if (e.button != null && e.button !== 0) return;
    if (e.target.closest('button')) return;

    const sel = window.getSelection();
    if (sel && !sel.isCollapsed && this.selectionInsideCard(card)) {
      if (this.pointInSelection(e.clientX, e.clientY, sel)) {
        e.preventDefault();
        e.stopPropagation();
        this.selDrag = {
          card,
          text: sel.toString(),
          startX: e.clientX,
          startY: e.clientY,
          moved: false,
          range: sel.getRangeAt(0).cloneRange()
        };
        return;
      }
    }

    this.pdfPress = {
      card,
      startX: e.clientX,
      startY: e.clientY,
      moved: false,
      pointerId: e.pointerId
    };
  },

  selectionInsideCard(card) {
    const sel = window.getSelection();
    if (!sel || !sel.anchorNode || !sel.focusNode) return false;
    const node = this.cardEls.get(card.id);
    if (!node) return false;
    return node.contains(sel.anchorNode) && node.contains(sel.focusNode);
  },

  pointInSelection(x, y, sel) {
    if (!sel || !sel.rangeCount) return false;
    const rects = sel.getRangeAt(0).getClientRects();
    for (let i = 0; i < rects.length; i++) {
      const r = rects[i];
      if (r.width < 1 && r.height < 1) continue;
      if (x >= r.left - 3 && x <= r.right + 3 && y >= r.top - 3 && y <= r.bottom + 3) return true;
    }
    return false;
  },

  showSelectionTools() {
    if (!this.entered) return;
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) { this.hideSelectionTools(); return; }

    const range = sel.getRangeAt(0);
    let node = range.commonAncestorContainer;
    if (node && node.nodeType === 3) node = node.parentElement;
    const layer = node && node.closest ? node.closest('.ws-text-layer') : null;
    if (!layer) { this.hideSelectionTools(); return; }
    const article = layer.closest('.ws-card');
    if (!article) { this.hideSelectionTools(); return; }
    const card = this.board.cards.find(c => c.id === article.dataset.id);
    if (!card || card.type !== 'pdf') { this.hideSelectionTools(); return; }

    const text = sel.toString().trim();
    if (!text) { this.hideSelectionTools(); return; }

    this.selection = { card, range: range.cloneRange(), text };
    let html = '<span>destacar</span>';
    WS_HL_COLORS.forEach(c => {
      html += '<button class="ws-sel-dot" data-hlcolor="' + c.value + '" title="Destacar em ' + c.label.toLowerCase() + '" style="background:' + c.value + '"></button>';
    });
    html += '<span style="opacity:.5">·</span>' +
      '<button class="ws-tool wide" data-selcard title="Criar um cartão com este trecho">' + svgIcon('file') + '<span>cartão</span></button>';
    this.els.selTools.innerHTML = html;

    const rect = range.getBoundingClientRect();
    const shellRect = this.els.shell.getBoundingClientRect();
    const tw = 236;
    let left = rect.left + rect.width / 2 - shellRect.left - tw / 2;
    left = clamp(left, 10, Math.max(10, shellRect.width - tw - 10));
    let top = rect.top - shellRect.top - 48;
    if (top < 62) top = rect.bottom - shellRect.top + 10;
    this.els.selTools.style.left = left + 'px';
    this.els.selTools.style.top = top + 'px';
    this.els.selTools.hidden = false;
  },

  hideSelectionTools() {
    this.selection = null;
    if (this.els.selTools) {
      this.els.selTools.hidden = true;
      this.els.selTools.innerHTML = '';
    }
  },

  clearNativeSelection() {
    try {
      const sel = window.getSelection();
      if (sel) sel.removeAllRanges();
    } catch (e) { /* ignora */ }
  },

  applyHighlight(color) {
    const sel = this.selection;
    if (!sel || !sel.card) return;
    const node = this.cardEls.get(sel.card.id);
    if (!node) return;
    const layer = node.querySelector('.ws-text-layer');
    if (!layer) return;
    const lr = layer.getBoundingClientRect();
    if (lr.width < 1 || lr.height < 1) return;

    const rects = [];
    const raw = sel.range.getClientRects();
    for (let i = 0; i < raw.length; i++) {
      const r = raw[i];
      if (r.width < 1 || r.height < 1) continue;
      const x1 = Math.max(r.left, lr.left);
      const y1 = Math.max(r.top, lr.top);
      const x2 = Math.min(r.right, lr.right);
      const y2 = Math.min(r.bottom, lr.bottom);
      if (x2 - x1 < 1 || y2 - y1 < 1) continue;
      rects.push({
        x: clamp((x1 - lr.left) / lr.width, 0, 1),
        y: clamp((y1 - lr.top) / lr.height, 0, 1),
        w: clamp((x2 - x1) / lr.width, 0, 1),
        h: clamp((y2 - y1) / lr.height, 0, 1)
      });
    }
    const meta = this.pdfMeta(sel.card);
    if (!meta || !rects.length) return;

    meta.highlights = meta.highlights || [];
    meta.highlights.push({
      id: uid(),
      page: sel.card.page,
      color: color,
      text: sel.text,
      rects
    });
    this.renderHighlights(sel.card);
    this.clearNativeSelection();
    this.hideSelectionTools();
    this.scheduleSave();
    toast('Trecho destacado', 'highlight');
  },

  selectionToCard() {
    const sel = this.selection;
    if (!sel) return;
    const rect = sel.range.getBoundingClientRect();
    const world = this.screenToWorld(
      rect.left + Math.min(rect.width, 240) / 2,
      rect.bottom + 26
    );
    this.createLinkedCardFromSelection(sel.card, sel.text, null, null, world);
    this.clearNativeSelection();
    this.hideSelectionTools();
  },

  createLinkedCardFromSelection(card, text, clientX, clientY, worldPoint) {
    if (!text || !text.trim()) return;
    let p = worldPoint;
    if (!p) {
      const shellRect = this.els.shell.getBoundingClientRect();
      p = this.screenToWorld(
        clientX == null ? shellRect.left + shellRect.width / 2 : clientX,
        clientY == null ? shellRect.top + shellRect.height / 2 : clientY
      );
    }
    const clean = text.replace(/\u00a0/g, ' ').replace(/[ \t]+\n/g, '\n').trim().slice(0, 6000);
    const note = this.addNote({
      x: p.x - 150,
      y: p.y - 50,
      w: 300,
      h: 190,
      text: clean,
      source: { pdfId: card.pdfId, page: card.page },
      focus: false
    });
    this.select(note.id);
    toast('Cartão ligado ao PDF criado', 'file');
  },

  ensureDragGhost(text) {
    if (this.dragGhost) return this.dragGhost;
    const g = el('div', 'ws-drag-ghost');
    const snippet = el('span');
    snippet.textContent = text.replace(/\s+/g, ' ').slice(0, 92);
    g.innerHTML = svgIcon('file');
    g.append(snippet);
    document.body.append(g);
    this.dragGhost = g;
    return g;
  },

  moveDragGhost(x, y, text) {
    const g = this.ensureDragGhost(text || '');
    g.style.left = (x + 16) + 'px';
    g.style.top = (y + 14) + 'px';
  },

  removeDragGhost() {
    if (this.dragGhost) this.dragGhost.remove();
    this.dragGhost = null;
  },

  /* -------- cronômetro flutuante -------- */
  buildTimer() {
    const root = this.els.timerRoot;
    root.innerHTML = '';
    const timer = el('div', 'ws-timer style-ring');
    timer.id = 'ws-timer';
    timer.innerHTML =
      '<div class="ws-timer-head">' +
        '<span class="ws-timer-mode">Foco</span>' +
        '<button class="ws-timer-btn" data-tact="settings" title="Configurações do cronômetro">' + svgIcon('sliders') + '</button>' +
        '<button class="ws-timer-btn" data-tact="min" title="Minimizar em bolinha">' + svgIcon('chevD') + '</button>' +
      '</div>' +
      '<div class="ws-timer-ball" title="Abrir cronômetro">25:00</div>' +
      '<div class="ws-timer-body">' +
        '<div class="ws-timer-ring">' +
          '<svg viewBox="0 0 100 100" aria-hidden="true">' +
            '<circle class="ws-timer-ring-bg" cx="50" cy="50" r="44"></circle>' +
            '<circle class="ws-timer-ring-fg" cx="50" cy="50" r="44"></circle>' +
          '</svg>' +
          '<span class="ws-timer-time"></span>' +
        '</div>' +
      '</div>' +
      '<span class="ws-timer-measure" aria-hidden="true"></span>' +
      '<div class="ws-timer-controls">' +
        '<button class="ws-timer-ctrl" data-tact="reset" title="Reiniciar">' + svgIcon('reset') + '</button>' +
        '<button class="ws-timer-ctrl main" data-tact="toggle" title="Iniciar">' + svgIcon('play') + '</button>' +
        '<button class="ws-timer-ctrl" data-tact="skip" title="Pular">' + svgIcon('skip') + '</button>' +
      '</div>';
    root.append(timer);

    const settings = el('div', 'ws-timer-settings');
    settings.hidden = true;
    root.append(settings);

    this.els.timer = timer;
    this.els.timerSettings = settings;

    const fg = timer.querySelector('.ws-timer-ring-fg');
    if (fg) fg.style.strokeDasharray = (2 * Math.PI * 44).toFixed(2);

    /* a fonte escolhida pode terminar de carregar depois: refaz as medidas do halo e do card */
    if (!this.fontsHooked && document.fonts && document.fonts.addEventListener) {
      this.fontsHooked = true;
      document.fonts.addEventListener('loadingdone', () => {
        if (!this.entered || !this.board) return;
        this.fitTimer();
        this.applyTimerPosition();
      });
    }

    timer.addEventListener('click', (e) => {
      const b = e.target.closest('[data-tact]');
      if (!b) return;
      e.stopPropagation();
      const act = b.dataset.tact;
      if (act === 'settings') this.openTimerSettings();
      else if (act === 'min') {
        this.board.timer.min = true;
        this.renderTimer();
        this.scheduleSave();
      } else if (act === 'toggle') {
        TimerPage.startPause();
        this.updateTimerFace();
      } else if (act === 'reset') {
        TimerPage.resetRuntime();
        Store.save();
        TimerPage.syncUI();
        this.updateTimerFace();
      } else if (act === 'skip') {
        TimerPage.skip();
        this.updateTimerFace();
      }
    });

    const head = timer.querySelector('.ws-timer-head');
    head.addEventListener('pointerdown', (e) => {
      if (e.target.closest('button')) return;
      this.startTimerDrag(e, false);
    });
    const ball = timer.querySelector('.ws-timer-ball');
    ball.addEventListener('pointerdown', (e) => this.startTimerDrag(e, true));

    settings.addEventListener('click', (e) => {
      const st = e.target.closest('[data-style]');
      if (st) {
        this.board.timer.style = st.dataset.style;
        this.renderTimer();
        this.renderTimerSettings();
        this.scheduleSave();
        return;
      }
      const col = e.target.closest('[data-color]');
      if (col) {
        this.board.timer.color = col.dataset.color;
        this.renderTimer();
        this.renderTimerSettings();
        this.scheduleSave();
        return;
      }
      const act = e.target.closest('[data-tact]');
      if (!act) return;
      if (act.dataset.tact === 'hide') {
        this.board.timer.visible = false;
        this.closeTimerSettings();
        this.renderTimer();
        this.scheduleSave();
      } else if (act.dataset.tact === 'resetpos') {
        this.board.timer.x = null;
        this.board.timer.y = null;
        this.applyTimerPosition();
        this.positionTimerSettings();
        this.scheduleSave();
      }
    });

    settings.addEventListener('input', (e) => {
      const range = e.target.closest('[data-range]');
      if (range) {
        const val = Number(range.value);
        if (range.dataset.range === 'size') this.board.timer.size = clamp(val, 20, 72);
        else this.board.timer.opacity = clamp(val, 20, 100);
        const out = range.parentElement.querySelector('[data-out]');
        if (out) out.textContent = range.dataset.range === 'size' ? val + 'px' : val + '%';
        this.renderTimer();
        this.scheduleSave();
        return;
      }
      const col = e.target.closest('[data-tcolor]');
      if (col) {
        this.board.timer.color = wsColor(col.value, '');
        this.renderTimer();
        this.scheduleSave();
      }
    });

    settings.addEventListener('change', (e) => {
      const font = e.target.closest('[data-tfont]');
      if (font) {
        this.board.timer.font = font.value;
        this.renderTimer();
        this.scheduleSave();
        return;
      }
      const col = e.target.closest('[data-tcolor]');
      if (col) {
        this.board.timer.color = wsColor(col.value, '');
        this.renderTimer();
        this.renderTimerSettings();
        this.scheduleSave();
      }
    });
  },

  timerFont() {
    const id = this.board.timer.font;
    const f = (typeof FONTS !== 'undefined' ? FONTS : []).find(x => x.id === id) || { id: 'inter', family: 'var(--font-ui)' };
    if (typeof Themes !== 'undefined' && Themes.ensureFonts) Themes.ensureFonts([f.id]);
    return f.family;
  },

  renderTimer() {
    if (!this.board || !this.els.timer) return;
    const t = this.board.timer;
    const node = this.els.timer;
    node.hidden = !t.visible;
    node.className = 'ws-timer style-' + t.style + (t.min ? ' min' : '');
    node.style.setProperty('--ws-timer-font', this.timerFont());
    node.style.setProperty('--ws-timer-size', t.size + 'px');
    if (t.color) node.style.setProperty('--ws-timer-tint', t.color);
    else node.style.removeProperty('--ws-timer-tint');
    node.style.opacity = (t.opacity / 100).toFixed(2);
    this.updateTimerFace();
    this.fitTimer();
    this.applyTimerPosition();
    if (this.els.timerSettings && !this.els.timerSettings.hidden) this.positionTimerSettings();
    this.updateTopbar();
  },

  /* O halo (anel) e a bolinha acompanham o tamanho real do relógio: mede o texto na fonte
     escolhida e dimensiona o círculo para que o tempo caiba por inteiro dentro dele. */
  fitTimer() {
    const node = this.els.timer;
    if (!node || node.hidden || !this.board) return;
    const m = node.querySelector('.ws-timer-measure');
    if (!m) return;
    const t = this.board.timer;
    const long = (this.lastTimerText || '').split(':').length > 2;
    const tpl = long ? '0:00:00' : '00:00';

    m.className = 'ws-timer-measure m-text';
    m.textContent = tpl;
    const rr = m.getBoundingClientRect();
    /* folga proporcional ao corpo da fonte, para o texto nunca encostar no traço do anel */
    const tw = rr.width + t.size * 0.35;
    const th = Math.max(rr.height, t.size) + t.size * 0.25;
    const ring = Math.max(96, Math.ceil(Math.hypot(tw, th) + 28));

    m.className = 'ws-timer-measure m-ball';
    const br = m.getBoundingClientRect();
    const ball = Math.max(56, Math.ceil(Math.hypot(br.width, br.height) + 18));

    const strokePx = clamp(ring * 0.04, 4, 10);
    node.style.setProperty('--ws-timer-ring', ring + 'px');
    node.style.setProperty('--ws-timer-ball', ball + 'px');
    node.style.setProperty('--ws-timer-stroke', (strokePx / ring * 100).toFixed(2));
  },

  /* mostra o tempo dígito a dígito (como a página Tempo): só o dígito que mudou é recriado/animado */
  renderTimerText(text) {
    const timeEl = this.els.timer && this.els.timer.querySelector('.ws-timer-time');
    if (!timeEl) return false;
    const flip = this.board.timer.style === 'flip';
    let rebuilt = false;
    if (timeEl.children.length !== text.length || this.timerChars.length !== text.length) {
      timeEl.innerHTML = '';
      this.timerChars = [];
      for (const ch of text) {
        const span = el('span', ch === ':' ? 'ws-t-colon' : 'ws-t-digit');
        span.textContent = ch;
        span.dataset.val = ch;
        timeEl.append(span);
        this.timerChars.push(span);
      }
      rebuilt = true;
    } else {
      for (let i = 0; i < text.length; i++) {
        const span = this.timerChars[i];
        const ch = text[i];
        if (span.dataset.val === ch) continue;
        span.dataset.val = ch;
        span.textContent = ch;
        if (flip && ch !== ':') {
          span.classList.remove('changed');
          void span.offsetWidth;
          span.classList.add('changed');
        }
      }
    }
    timeEl.setAttribute('aria-label', text);
    return rebuilt;
  },

  applyTimerPosition() {
    if (!this.board || !this.els.timer) return;
    const t = this.board.timer;
    const r = this.els.shell.getBoundingClientRect();
    if (r.width < 40 || r.height < 40) return;
    if (this.els.timer.hidden) return;
    /* mede o card real (o tamanho muda com a fonte, o estilo e a bolinha) */
    const w = this.els.timer.offsetWidth || (t.min ? 56 : 196);
    const h = this.els.timer.offsetHeight || (t.min ? 56 : 224);
    // deixa um corredor à direita para o controle de zoom não ficar sob o cronômetro
    const rightGuard = 60;
    if (t.x == null) t.x = r.width - w - 88;
    if (t.y == null) t.y = r.height - h - 62;
    t.x = clamp(t.x, 8, Math.max(8, r.width - w - rightGuard));
    t.y = clamp(t.y, 8, Math.max(8, r.height - h - 8));
    this.els.timer.style.left = t.x + 'px';
    this.els.timer.style.top = t.y + 'px';
  },

  startTimerDrag(e, ball) {
    if (e.button != null && e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    this.closeTimerSettings();
    const t = this.board.timer;
    this.applyTimerPosition();
    this.timerDrag = {
      startX: e.clientX,
      startY: e.clientY,
      origX: t.x,
      origY: t.y,
      moved: false,
      ball: !!ball
    };
    this.els.timer.classList.add('dragging');
  },

  updateTimerFace() {
    if (!this.board || !this.els.timer) return;
    if (typeof TimerPage === 'undefined') return;
    const t = Store.state.timer;
    const countdown = t.tab === 'countdown';
    const total = TimerPage.presetTotal();
    const rem = TimerPage.remainingNow();
    const elapsed = TimerPage.elapsedNow();
    const text = countdown ? fmtClock(rem) : fmtClock(elapsed);
    const progress = countdown
      ? clamp(rem / Math.max(1, total), 0, 1)
      : ((elapsed % 3600) / 3600);

    const ball = this.els.timer.querySelector('.ws-timer-ball');
    const rebuilt = this.renderTimerText(text);
    if (ball && ball.textContent !== text) ball.textContent = text;

    const preset = (typeof TIMER_PRESETS !== 'undefined' ? TIMER_PRESETS : []).find(p => p.id === t.preset);
    const mode = countdown ? (preset ? preset.label : 'Foco') : 'Cronômetro';
    const modeEl = this.els.timer.querySelector('.ws-timer-mode');
    if (modeEl) modeEl.textContent = mode + (t.running ? ' · ativo' : '');

    const fg = this.els.timer.querySelector('.ws-timer-ring-fg');
    if (fg) {
      const c = 2 * Math.PI * 44;
      fg.style.strokeDashoffset = (c * (1 - progress)).toFixed(2);
    }

    const btn = this.els.timer.querySelector('[data-tact="toggle"]');
    if (btn) {
      const state = t.running ? 'pause' : 'play';
      if (btn.dataset.state !== state) {
        btn.dataset.state = state;
        btn.innerHTML = svgIcon(state);
        btn.title = t.running ? 'Pausar' : 'Iniciar';
      }
    }
    const lenChanged = (this.lastTimerText || '').length !== text.length;
    this.lastTimerText = text;
    /* o texto ganhou/perdeu dígitos (ex.: 59:59 → 1:00:00): ajusta o halo e o card */
    if (rebuilt && lenChanged && !this.els.timer.hidden) {
      this.fitTimer();
      this.applyTimerPosition();
    }
  },

  startTimerLoop() {
    this.stopTimerLoop();
    this.updateTimerFace();
    this.timerIv = setInterval(() => {
      if (this.entered) this.updateTimerFace();
    }, 250);
  },

  stopTimerLoop() {
    clearInterval(this.timerIv);
    this.timerIv = null;
  },

  toggleTimerVisible() {
    const t = this.board.timer;
    t.visible = !t.visible;
    if (t.visible) {
      this.applyTimerPosition();
      this.renderTimer();
    } else {
      this.closeTimerSettings();
      this.renderTimer();
    }
    this.scheduleSave();
  },

  openTimerSettings() {
    if (!this.board.timer.visible) {
      this.board.timer.visible = true;
      this.renderTimer();
    }
    if (!this.els.timerSettings.hidden) { this.closeTimerSettings(); return; }
    this.closePopover();
    this.els.timerSettings.hidden = false;
    this.renderTimerSettings();
    this.positionTimerSettings();
  },

  closeTimerSettings() {
    if (this.els.timerSettings) this.els.timerSettings.hidden = true;
  },

  positionTimerSettings() {
    if (!this.board || !this.els.timerSettings || this.els.timerSettings.hidden) return;
    const t = this.board.timer;
    const r = this.els.shell.getBoundingClientRect();
    const box = this.els.timerSettings;
    const bw = 272;
    box.style.maxHeight = Math.max(200, r.height - 16) + 'px';
    const bh = Math.min(box.scrollHeight || 420, Math.max(200, r.height - 16));
    const nw = this.els.timer.offsetWidth || (t.min ? 56 : 196);
    let left = t.x - bw - 12;
    if (left < 8) left = t.x + nw + 12;
    left = clamp(left, 8, Math.max(8, r.width - bw - 8));
    const top = clamp(t.y, 8, Math.max(8, r.height - bh - 8));
    box.style.left = left + 'px';
    box.style.top = top + 'px';
  },

  renderTimerSettings() {
    const box = this.els.timerSettings;
    if (!box) return;
    const t = this.board.timer;
    const prev = {
      minimal: '<span class="ws-sp ws-sp-min">25</span>',
      ring:    '<span class="ws-sp ws-sp-ring"></span>',
      flip:    '<span class="ws-sp ws-sp-flip"><b>2</b><b>5</b></span>'
    };
    let html = '<div class="ws-tset-head"><p class="ws-pop-title">Cronômetro flutuante</p>' +
      '<span class="ws-tset-sub">Mesmo tempo da página Tempo. Tudo aqui é só visual.</span></div>';

    /* 1 — forma do relógio */
    html += '<section class="ws-tset-group"><h4>Estilo</h4>' +
      '<p class="ws-tset-hint">Escolha o formato do relógio.</p><div class="ws-style-row">';
    WS_TIMER_STYLES.forEach(s => {
      html += '<button class="ws-style-btn' + (t.style === s.id ? ' active' : '') + '" data-style="' + s.id + '">' +
        prev[s.id] + '<span>' + s.label + '</span></button>';
    });
    html += '</div></section>';

    /* 2 — cor */
    html += '<section class="ws-tset-group"><h4>Cor</h4>' +
      '<p class="ws-tset-hint">Dígitos e halo usam a mesma cor.</p><div class="ws-color-grid">';
    WS_TIMER_COLORS.forEach(c => {
      const bg = c.value || 'var(--accent)';
      html += '<button class="ws-swatch' + (t.color === c.value ? ' active' : '') + '" data-color="' + c.value + '" title="' + c.label + '" style="background:' + bg + '"></button>';
    });
    html += '</div><label class="ws-color-custom"><input type="color" value="' +
      (wsColor(t.color, '#8fa2ff') || '#8fa2ff') + '" data-tcolor><span>Cor personalizada</span></label></section>';

    /* 3 — fonte e tamanho */
    html += '<section class="ws-tset-group"><h4>Fonte e tamanho</h4>' +
      '<p class="ws-tset-hint">O halo e o card crescem junto com o tamanho.</p>' +
      '<div class="ws-range-row"><span>Fonte</span><select class="ws-select" data-tfont>';
    (typeof FONTS !== 'undefined' ? FONTS : []).forEach(f => {
      html += '<option value="' + f.id + '"' + (f.id === t.font ? ' selected' : '') + '>' + f.label + '</option>';
    });
    html += '</select></div>' +
      '<div class="ws-range-row"><span>Tamanho <b data-out>' + t.size + 'px</b></span>' +
      '<input type="range" min="20" max="72" step="1" value="' + t.size + '" data-range="size"></div></section>';

    /* 4 — janela */
    html += '<section class="ws-tset-group"><h4>Janela</h4>' +
      '<div class="ws-range-row"><span>Transparência <b data-out>' + t.opacity + '%</b></span>' +
      '<input type="range" min="20" max="100" step="1" value="' + t.opacity + '" data-range="opacity"></div>' +
      '<div class="ws-pop-row" style="margin-top:12px">' +
      '<button class="ws-pop-chip" data-tact="resetpos">Posição padrão</button>' +
      '<button class="ws-pop-chip" data-tact="hide">Ocultar</button></div>' +
      '<p class="ws-pop-note">Arraste pelo topo para mover; o botão de seta minimiza em bolinha.</p></section>';

    box.innerHTML = html;
    this.positionTimerSettings();
  },

};
