'use strict';
/* ============ pages/tasks.js — tarefas ============ */
const TasksPage = {
  filter: 'all',

  init() {
    $('#tasks-add').innerHTML = svgIcon('plus');
    const ghost = $('#ghost-tasks');
    if (ghost) ghost.innerHTML = svgIcon('tasks');
    this.applyConfig();

    $('#tasks-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this.add();
    });

    $$('#tasks-filters .filter-chip').forEach(b => {
      b.addEventListener('click', () => {
        this.filter = b.dataset.filter;
        $$('#tasks-filters .filter-chip').forEach(x => x.classList.toggle('active', x === b));
        this.render();
      });
    });

    $('#tasks-clear').addEventListener('click', () => this.clearDone());

    this.render();
  },

  applyConfig() {
    const t = Store.state.tasks;
    const page = $('#page-tasks');
    page.style.setProperty('--task-accent', t.accent || 'var(--accent)');
    page.dataset.anim = t.anim;
  },

  add() {
    const input = $('#tasks-input');
    const text = input.value.trim();
    if (!text) { input.focus(); return; }
    Store.state.tasks.items.unshift({
      id: uid(),
      text: text,
      done: false,
      createdAt: new Date().toISOString(),
      doneAt: null
    });
    Store.save();
    input.value = '';
    input.focus();
    this.filter = this.filter === 'done' ? 'all' : this.filter;
    this.render(true);
  },

  toggle(id) {
    const item = Store.state.tasks.items.find(t => t.id === id);
    if (!item) return;
    item.done = !item.done;
    item.doneAt = item.done ? new Date().toISOString() : null;
    Store.state.tracker.tasksCompleted = Math.max(0, Store.state.tracker.tasksCompleted + (item.done ? 1 : -1));
    if (item.done && Store.state.tasks.popSound) Sound.pop();
    Store.save();
    this.render();
    if (typeof TrackerPage !== 'undefined') TrackerPage.softRefresh();
    if (typeof HomePage !== 'undefined') HomePage.renderChips();
  },

  startEdit(id) {
    const item = Store.state.tasks.items.find(t => t.id === id);
    if (!item) return;
    const li = document.querySelector('.task[data-id="' + id + '"]');
    if (!li) return;
    const span = $('.task-text', li);
    if (!span) return;

    const input = el('input', 'task-edit');
    input.type = 'text';
    input.maxLength = 200;
    input.value = item.text;
    span.replaceWith(input);
    input.focus();
    input.select();

    let done = false;
    const finish = (save) => {
      if (done) return;
      done = true;
      const val = input.value.trim();
      if (save && val && val !== item.text) {
        item.text = val;
        Store.save();
        toast('Tarefa atualizada', 'pencil');
      }
      this.render();
      if (typeof HomePage !== 'undefined') HomePage.renderChips();
    };

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      else if (e.key === 'Escape') { e.preventDefault(); finish(false); }
    });
    input.addEventListener('blur', () => finish(true));
  },

  remove(id) {
    const li = document.querySelector('.task[data-id="' + id + '"]');
    const finish = () => {
      Store.state.tasks.items = Store.state.tasks.items.filter(t => t.id !== id);
      Store.save();
      this.render();
      if (typeof HomePage !== 'undefined') HomePage.renderChips();
    };
    if (li) { li.classList.add('exit'); setTimeout(finish, 240); }
    else finish();
  },

  clearDone() {
    const done = Store.state.tasks.items.filter(t => t.done);
    if (!done.length) { toast('Nenhuma tarefa concluída', 'checkc'); return; }
    Store.state.tasks.items = Store.state.tasks.items.filter(t => !t.done);
    Store.save();
    this.render();
    toast(done.length + (done.length === 1 ? ' tarefa removida' : ' tarefas removidas'), 'trash');
  },

  sortItems(items) {
    const cfg = Store.state.tasks;
    const sort = cfg.sort || 'recent';
    return items.sort((a, b) => {
      if (cfg.doneLast && a.done !== b.done) return a.done ? 1 : -1;
      if (sort === 'alpha') return a.text.localeCompare(b.text, 'pt-BR');
      if (sort === 'oldest') return (a.createdAt || '').localeCompare(b.createdAt || '');
      return (b.createdAt || '').localeCompare(a.createdAt || '');
    });
  },

  render(withEnterAnim) {
    const cfg = Store.state.tasks;
    let items = cfg.items.slice();
    if (this.filter === 'pending') items = items.filter(t => !t.done);
    else if (this.filter === 'done') items = items.filter(t => t.done);
    items = this.sortItems(items);

    const list = $('#task-list');
    list.innerHTML = '';
    items.forEach(item => {
      const li = el('li', 'task' + (item.done ? ' done' : ''));
      li.dataset.id = item.id;
      const check = el('button', 'task-check', svgIcon('check'));
      check.title = item.done ? 'Reabrir tarefa' : 'Concluir tarefa';
      check.setAttribute('aria-label', check.title);
      check.addEventListener('click', () => this.toggle(item.id));

      const span = el('span', 'task-text');
      span.textContent = item.text;
      span.title = 'Duplo clique para editar';
      span.addEventListener('dblclick', () => this.startEdit(item.id));

      const edit = el('button', 'task-edit-btn', svgIcon('pencil'));
      edit.title = 'Editar';
      edit.setAttribute('aria-label', 'Editar tarefa');
      edit.addEventListener('click', () => this.startEdit(item.id));

      const del = el('button', 'task-del', svgIcon('trash'));
      del.title = 'Excluir';
      del.setAttribute('aria-label', 'Excluir tarefa');
      del.addEventListener('click', () => this.remove(item.id));

      li.append(check, span, edit, del);
      list.append(li);
    });

    const pending = cfg.items.filter(t => !t.done).length;
    $('#tasks-count').textContent = pending === 0
      ? (cfg.items.length ? 'tudo em ordem ✨' : 'uma lista limpa, uma mente limpa')
      : pending + (pending === 1 ? ' pendente' : ' pendentes');
    $('#tasks-empty').style.display = items.length ? 'none' : 'block';
    $('#tasks-clear').style.visibility = cfg.items.some(t => t.done) ? 'visible' : 'hidden';

    if (withEnterAnim) {
      const first = list.firstElementChild;
      if (first) {
        first.classList.add('enter');
        first.addEventListener('animationend', () => first.classList.remove('enter'), { once: true });
      }
    }
  }
};
