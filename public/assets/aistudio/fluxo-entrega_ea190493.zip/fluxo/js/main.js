'use strict';
/* ============ main.js — inicialização ============ */
async function boot() {
  Store.load();

  // respeita a preferência do sistema por menos movimento
  if (Store.fresh && window.matchMedia &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    Store.state.motion.enabled = false;
    Store.save();
  }

  Sound.init();
  Themes.apply();

  await Files.init();
  await Themes.loadCustomFiles();

  Motion.init();

  HomePage.init();
  TimerPage.init();
  TrackerPage.init();
  TasksPage.init();

  Usage.start();
  Router.init();
  Panel.init();
  Idle.init();

  // rota inicial
  if (!location.hash) {
    try { history.replaceState(null, '', '#/inicio'); } catch (e) { location.hash = '#/inicio'; }
    Router.go();
  }

  // dica de primeira visita
  if (!Store.state.meta.seenTip) {
    Store.state.meta.seenTip = true;
    Store.save();
    setTimeout(() => toast('Toque na bolinha para navegar, arraste para movê-la e personalizar tudo', 'sparkle'), 1400);
  }
}

boot();
